package com.studyflow.app.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZoneOffset

class SessionSplitterTest {
    private fun millis(dt: LocalDateTime, zone: ZoneId) = dt.atZone(zone).toInstant().toEpochMilli()

    @Test fun sameDay_isNotSplit() {
        val zone = ZoneOffset.UTC
        val seg = Segment(millis(LocalDateTime.of(2026, 3, 1, 10, 0), zone), millis(LocalDateTime.of(2026, 3, 1, 11, 0), zone), 3_600_000)
        val r = SessionSplitter.splitByDate(seg, zone)
        assertEquals(mapOf(LocalDate.of(2026, 3, 1) to 3_600_000L), r)
    }

    @Test fun acrossMidnight_splitsEvenlyAndSumsExactly() {
        val zone = ZoneOffset.UTC
        val seg = Segment(millis(LocalDateTime.of(2026, 3, 1, 23, 30), zone), millis(LocalDateTime.of(2026, 3, 2, 0, 30), zone), 3_600_000)
        val r = SessionSplitter.splitByDate(seg, zone)
        assertEquals(1_800_000L, r[LocalDate.of(2026, 3, 1)])
        assertEquals(1_800_000L, r[LocalDate.of(2026, 3, 2)])
        assertEquals(3_600_000L, r.values.sum())
    }

    @Test fun multiDay_sumsToActive() {
        val zone = ZoneId.of("America/New_York")
        val start = millis(LocalDateTime.of(2026, 3, 7, 22, 0), zone)
        val end = millis(LocalDateTime.of(2026, 3, 9, 2, 0), zone) // crosses the DST change
        val active = 12_345_678L
        val r = SessionSplitter.splitByDate(Segment(start, end, active), zone)
        assertEquals(3, r.size)
        assertEquals(active, r.values.sum())
        assertTrue(r.values.all { it > 0 })
    }

    @Test fun zeroActive_returnsEmpty() {
        assertTrue(SessionSplitter.splitByDate(Segment(0, 1000, 0), ZoneOffset.UTC).isEmpty())
    }

    @Test fun codecRoundTrip() {
        val list = listOf(Segment(1, 2, 3), Segment(10, 20, 5))
        assertEquals(list, SegmentCodec.decode(SegmentCodec.encode(list)))
        assertTrue(SegmentCodec.decode("").isEmpty())
        assertTrue(SegmentCodec.decode("garbage;1,2").isEmpty())
    }

    @Test fun timerMath_excludesPausedTimeAndNeverNegative() {
        assertEquals(5_000L, TimerMath.activeMillis(5_000, false, null, 999_999))
        assertEquals(8_000L, TimerMath.activeMillis(5_000, true, 1_000, 4_000))
        assertEquals(5_000L, TimerMath.activeMillis(5_000, true, 10_000, 4_000))
    }
}
