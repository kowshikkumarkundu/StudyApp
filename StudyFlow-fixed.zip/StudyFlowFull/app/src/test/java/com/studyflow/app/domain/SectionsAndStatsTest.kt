package com.studyflow.app.domain

import com.studyflow.app.data.db.RevisionEntity
import com.studyflow.app.data.db.RevisionKind
import com.studyflow.app.data.db.RevisionStatus
import com.studyflow.app.data.db.SessionType
import com.studyflow.app.data.db.SubjectEntity
import com.studyflow.app.data.db.TopicEntity
import com.studyflow.app.data.db.TopicStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneOffset

class SectionsAndStatsTest {
    private val today = LocalDate.of(2026, 5, 10)

    private fun rev(id: Long, dayOffset: Long, status: RevisionStatus = RevisionStatus.PENDING) =
        RevisionItem(
            RevisionEntity(id, 1, RevisionKind.AUTO, id.toInt(), today.plusDays(dayOffset).toEpochDay(), status),
            "Topic", "Subject"
        )

    @Test fun missedAndTodayAreNeverMixed() {
        val items = listOf(rev(1, -3), rev(2, 0), rev(3, 4), rev(4, -1, RevisionStatus.COMPLETED), rev(5, 0, RevisionStatus.COMPLETED))
        val s = Sections.revisions(items, today.toEpochDay())
        assertEquals(listOf(2L, 5L), s.today.map { it.revision.id })
        assertEquals(listOf(1L), s.missed.map { it.revision.id })
        assertEquals(listOf(3L), s.upcoming.map { it.revision.id })
        assertTrue(s.missed.none { it in s.today })
    }

    @Test fun statsUseSegmentsAndSplitDays() {
        val zone = ZoneOffset.UTC
        fun ms(dt: LocalDateTime) = dt.atZone(zone).toInstant().toEpochMilli()
        val segments = listOf(
            SegmentRecord(SessionType.MAIN, 1, ms(today.minusDays(1).atTime(23, 30)), ms(today.atTime(0, 30)), 3_600_000),
            SegmentRecord(SessionType.REVISION, 2, ms(today.atTime(9, 0)), ms(today.atTime(9, 30)), 1_800_000)
        )
        val topics = listOf(
            TopicEntity(1, 1, "A", today.toEpochDay(), TopicStatus.COMPLETED),
            TopicEntity(2, 2, "B", today.toEpochDay(), TopicStatus.PLANNED)
        )
        val subjects = listOf(SubjectEntity(1, "Math", 0), SubjectEntity(2, "Art", 0))
        val revisions = listOf(
            RevisionEntity(1, 1, RevisionKind.AUTO, 1, today.minusDays(2).toEpochDay()),
            RevisionEntity(2, 1, RevisionKind.AUTO, 3, today.toEpochDay(), RevisionStatus.COMPLETED)
        )
        val r = StatsCalculator.compute(segments, topics, subjects, revisions, today, zone)
        assertEquals(1_800_000L, r.todayMainMillis)
        assertEquals(1_800_000L, r.todayRevisionMillis)
        assertEquals(5_400_000L, r.totalMillis)
        assertEquals(1, r.topicsCompleted); assertEquals(2, r.topicsTotal)
        assertEquals(1, r.revisionsCompleted); assertEquals(2, r.revisionsTotal)
        assertEquals(1, r.missedRevisions)
        assertEquals(7, r.last7Days.size)
        assertEquals(5_400_000L / 7, r.dailyAverageMillis)
        assertEquals("Math", r.subjects.first().subjectName)
        assertEquals(6, r.months.size)
        assertEquals(5_400_000L, r.months.last().millis)
    }
}
