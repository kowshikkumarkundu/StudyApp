package com.studyflow.app.data

import com.studyflow.app.data.db.Converters
import com.studyflow.app.data.db.RevisionKind
import com.studyflow.app.data.db.RevisionStatus
import com.studyflow.app.data.db.SessionType
import com.studyflow.app.data.db.TimerStatus
import com.studyflow.app.data.db.TopicStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ConvertersTest {
    private val c = Converters()

    @Test fun allEnumsRoundTrip() {
        TopicStatus.values().forEach { assertEquals(it, c.toTopicStatus(c.fromTopicStatus(it))) }
        SessionType.values().forEach { assertEquals(it, c.toSessionType(c.fromSessionType(it))) }
        RevisionKind.values().forEach { assertEquals(it, c.toRevisionKind(c.fromRevisionKind(it))) }
        RevisionStatus.values().forEach { assertEquals(it, c.toRevisionStatus(c.fromRevisionStatus(it))) }
        TimerStatus.values().forEach { assertEquals(it, c.toTimerStatus(c.fromTimerStatus(it))) }
    }

    @Test fun nullableSessionType() {
        assertNull(c.fromSessionTypeOrNull(null))
        assertNull(c.toSessionTypeOrNull(null))
        assertEquals(SessionType.MAIN, c.toSessionTypeOrNull("MAIN"))
    }
}
