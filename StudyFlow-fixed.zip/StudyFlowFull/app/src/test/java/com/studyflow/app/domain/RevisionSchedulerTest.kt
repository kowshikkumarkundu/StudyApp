package com.studyflow.app.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import java.time.LocalDate

class RevisionSchedulerTest {
    @Test fun defaultIntervals_dayOneIsNextCalendarDay() {
        val result = RevisionScheduler.schedule(LocalDate.of(2026, 1, 10), RevisionScheduler.DEFAULT_INTERVALS)
        assertEquals(listOf(1, 3, 7, 15, 30), result.map { it.intervalDays })
        assertEquals(LocalDate.of(2026, 1, 11), result[0].date)
        assertEquals(LocalDate.of(2026, 1, 13), result[1].date)
        assertEquals(LocalDate.of(2026, 1, 17), result[2].date)
        assertEquals(LocalDate.of(2026, 1, 25), result[3].date)
        assertEquals(LocalDate.of(2026, 2, 9), result[4].date)
    }

    @Test fun crossesMonthAndYearBoundary() {
        val result = RevisionScheduler.schedule(LocalDate.of(2026, 12, 31), listOf(1))
        assertEquals(LocalDate.of(2027, 1, 1), result.single().date)
    }

    @Test fun ignoresDuplicatesAndNonPositive() {
        val result = RevisionScheduler.schedule(LocalDate.of(2026, 1, 1), listOf(7, 0, -2, 7, 3))
        assertEquals(listOf(3, 7), result.map { it.intervalDays })
    }

    @Test fun parseIntervals_validAndInvalid() {
        assertEquals(listOf(1, 3, 7), RevisionScheduler.parseIntervals("7, 3,1 , 3"))
        assertNull(RevisionScheduler.parseIntervals(""))
        assertNull(RevisionScheduler.parseIntervals("1, abc"))
        assertNull(RevisionScheduler.parseIntervals("0, 5"))
        assertNull(RevisionScheduler.parseIntervals("400"))
    }
}
