package com.studyflow.app.util

import org.junit.Assert.assertEquals
import org.junit.Test

class DurationFormatTest {
    @Test fun hms() {
        assertEquals("00:00:00", DurationFormat.hms(0))
        assertEquals("01:01:01", DurationFormat.hms(3_661_000))
        assertEquals("25:00:00", DurationFormat.hms(90_000_000))
        assertEquals("00:00:00", DurationFormat.hms(-5))
    }

    @Test fun hm() {
        assertEquals("0m", DurationFormat.hm(0))
        assertEquals("<1m", DurationFormat.hm(30_000))
        assertEquals("45m", DurationFormat.hm(45 * 60_000L))
        assertEquals("2h 05m", DurationFormat.hm(125 * 60_000L))
    }
}
