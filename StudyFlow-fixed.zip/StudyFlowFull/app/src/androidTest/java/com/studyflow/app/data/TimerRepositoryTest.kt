package com.studyflow.app.data

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.studyflow.app.data.db.SessionType
import com.studyflow.app.data.db.StudyFlowDatabase
import com.studyflow.app.data.db.TimerStatus
import com.studyflow.app.data.repository.StopResult
import com.studyflow.app.data.repository.StudyRepository
import com.studyflow.app.data.repository.TimerRepository
import com.studyflow.app.data.repository.ValidationException
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class TimerRepositoryTest {
    private lateinit var db: StudyFlowDatabase
    private lateinit var time: FakeTimeSource
    private lateinit var study: StudyRepository
    private lateinit var timer: TimerRepository

    @Before fun setUp() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(ctx, StudyFlowDatabase::class.java).allowMainThreadQueries().build()
        time = FakeTimeSource()
        study = StudyRepository(db, time)
        timer = TimerRepository(db, study, time)
    }

    @After fun tearDown() = db.close()

    @Test fun pausedTimeIsExcluded() = runBlocking {
        val topic = study.addTopic("Math", "Algebra", 20000)
        timer.start(SessionType.MAIN, topic)
        time.advance(60_000)
        timer.pause()
        time.advance(600_000) // paused for 10 minutes
        timer.resume()
        time.advance(30_000)
        val result = timer.stop()
        assertEquals(StopResult.Saved(90_000), result)
        assertEquals(90_000L, db.studySessionDao().getAll().single().activeMillis)
        assertEquals(2, db.segmentDao().getAll().size)
    }

    @Test fun onlyOneActiveTimer() = runBlocking {
        val topic = study.addTopic("Math", "Algebra", 20000)
        timer.start(SessionType.MAIN, topic)
        try {
            timer.start(SessionType.REVISION, topic)
            throw AssertionError("second timer should be rejected")
        } catch (e: ValidationException) {
            assertTrue(e.message!!.contains("already active"))
        }
    }

    @Test fun rebootRecoversFromCheckpointAndPauses() = runBlocking {
        val topic = study.addTopic("Math", "Algebra", 20000)
        timer.start(SessionType.MAIN, topic)
        time.advance(120_000)
        timer.checkpoint()
        time.advance(50_000)
        // simulate reboot: boot counter changes and the monotonic clock restarts
        time.boot = 2
        time.elapsed = 5_000
        timer.recoverIfNeeded()
        val state = db.timerStateDao().get()!!
        assertEquals(TimerStatus.PAUSED, state.status)
        assertEquals(120_000L, state.accumulatedActiveMillis)
        assertTrue(state.wasRecovered)
        assertEquals(StopResult.Saved(120_000), timer.stop())
    }
}
