package com.studyflow.app.data

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.studyflow.app.data.db.RevisionKind
import com.studyflow.app.data.db.RevisionStatus
import com.studyflow.app.data.db.SessionType
import com.studyflow.app.data.db.StudyFlowDatabase
import com.studyflow.app.data.db.StudySessionEntity
import com.studyflow.app.data.repository.StudyRepository
import com.studyflow.app.domain.RevisionScheduler
import com.studyflow.app.domain.Segment
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.time.LocalDate
import java.time.ZoneOffset

@RunWith(AndroidJUnit4::class)
class RevisionEngineTest {
    private lateinit var db: StudyFlowDatabase
    private lateinit var repo: StudyRepository
    private val firstDay = LocalDate.of(2026, 1, 10)

    @Before fun setUp() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(ctx, StudyFlowDatabase::class.java).allowMainThreadQueries().build()
        repo = StudyRepository(db, FakeTimeSource())
    }

    @After fun tearDown() = db.close()

    private fun startOf(day: LocalDate) = day.atTime(10, 0).toInstant(ZoneOffset.UTC).toEpochMilli()

    private suspend fun saveMain(topicId: Long, day: LocalDate) {
        val start = startOf(day)
        repo.saveSession(
            StudySessionEntity(topicId = topicId, type = SessionType.MAIN, startWallMillis = start, endWallMillis = start + 60_000, activeMillis = 60_000),
            listOf(Segment(start, start + 60_000, 60_000))
        )
    }

    @Test fun stoppingMainSessions_doesNotGenerateSchedule_untilExplicitCompletion() = runBlocking {
        val topicId = repo.addTopic("Math", "Algebra", firstDay.toEpochDay())
        saveMain(topicId, firstDay)
        saveMain(topicId, firstDay.plusDays(2))
        assertEquals(0, db.revisionDao().getAll().size)
        assertEquals(2, db.studySessionDao().getAll().size)
    }

    @Test fun explicitCompletion_generatesFiveRevisions_onlyOnce() = runBlocking {
        val fakeTime = FakeTimeSource(wall = startOf(firstDay), elapsed = 1_000_000L)
        val completionRepo = StudyRepository(db, fakeTime)
        val topicId = completionRepo.addTopic("Math", "Geometry", firstDay.toEpochDay())
        completionRepo.completeTopic(topicId, RevisionScheduler.DEFAULT_INTERVALS)
        completionRepo.completeTopic(topicId, RevisionScheduler.DEFAULT_INTERVALS)
        val revisions = db.revisionDao().getAll().filter { it.topicId == topicId }.sortedBy { it.scheduledEpochDay }
        assertEquals(5, revisions.size)
        assertEquals(listOf(1, 3, 7, 15, 30), revisions.map { it.intervalDays })
        assertEquals(firstDay.plusDays(1).toEpochDay(), revisions.first().scheduledEpochDay)
    }

    @Test fun completingOne_orAddingManual_neverShiftsOtherDates() = runBlocking {
        val topicId = repo.addTopic("Math", "Algebra", firstDay.toEpochDay())
        saveMain(topicId, firstDay)
        val fakeTime = FakeTimeSource(wall = startOf(firstDay), elapsed = 1_000_000L)
        StudyRepository(db, fakeTime).completeTopic(topicId, RevisionScheduler.DEFAULT_INTERVALS)
        val before = db.revisionDao().getAll().associate { it.id to it.scheduledEpochDay }
        val missed = db.revisionDao().getAll().first { it.intervalDays == 1 }
        repo.completeRevision(missed.id)
        repo.addManualRevision(topicId, firstDay.plusDays(5).toEpochDay())
        val after = db.revisionDao().getAll()
        before.forEach { (id, day) -> assertEquals(day, after.first { it.id == id }.scheduledEpochDay) }
        assertEquals(RevisionStatus.COMPLETED, after.first { it.id == missed.id }.status)
        assertEquals(1, after.count { it.kind == RevisionKind.MANUAL })
        assertEquals(5, after.count { it.kind == RevisionKind.AUTO })
    }

    @Test fun revisionSession_doesNotGenerateSchedule() = runBlocking {
        val topicId = repo.addTopic("Math", "Algebra", firstDay.toEpochDay())
        val start = startOf(firstDay)
        repo.saveSession(
            StudySessionEntity(topicId = topicId, type = SessionType.REVISION, startWallMillis = start, endWallMillis = start + 5_000, activeMillis = 5_000),
            listOf(Segment(start, start + 5_000, 5_000))
        )
        assertEquals(0, db.revisionDao().getAll().size)
    }
}
