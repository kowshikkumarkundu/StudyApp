package com.studyflow.app.data

import com.studyflow.app.util.TimeSource
import java.time.ZoneId
import java.time.ZoneOffset

class FakeTimeSource(
    var wall: Long = 1_700_000_000_000L,
    var elapsed: Long = 1_000_000L,
    var boot: Int = 1
) : TimeSource {
    override fun wallMillis() = wall
    override fun elapsedRealtime() = elapsed
    override fun bootCount() = boot
    override fun zone(): ZoneId = ZoneOffset.UTC

    fun advance(ms: Long) { wall += ms; elapsed += ms }
}
