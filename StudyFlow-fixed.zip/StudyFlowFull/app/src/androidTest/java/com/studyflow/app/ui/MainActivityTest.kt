package com.studyflow.app.ui

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.studyflow.app.MainActivity
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class MainActivityTest {
    @get:Rule val rule = createAndroidComposeRule<MainActivity>()

    @Test fun bottomNavigation_switchesScreens() {
        rule.onNodeWithText("Home").assertIsDisplayed()
        rule.onNodeWithText("Settings").performClick()
        rule.onNodeWithText("Appearance").assertIsDisplayed()
        rule.onNodeWithText("Statistics").performClick()
        rule.waitUntil(5_000) { rule.onAllNodesWithText("Today").fetchSemanticsNodes().isNotEmpty() }
        rule.onNodeWithText("Today").assertIsDisplayed()
    }

    @Test fun homeShowsStudyRevisionAndMissedTabs() {
        rule.onNodeWithText("Study").assertIsDisplayed()
        rule.onNodeWithText("Revision").assertIsDisplayed()
        rule.onNodeWithText("Missed (0)").assertIsDisplayed()
    }
}
