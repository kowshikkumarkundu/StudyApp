package com.studyflow.app.data.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.studyflow.app.domain.RevisionScheduler
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

enum class ThemeMode { SYSTEM, LIGHT, DARK }

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val use24Hour: Boolean = false,
    val dailyGoalMinutes: Int = 120,
    val revisionIntervals: List<Int> = RevisionScheduler.DEFAULT_INTERVALS
)

private val Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

class SettingsRepository(private val context: Context) {
    private val themeKey = stringPreferencesKey("theme_mode")
    private val use24Key = booleanPreferencesKey("use_24_hour")
    private val goalKey = intPreferencesKey("daily_goal_minutes")
    private val intervalsKey = stringPreferencesKey("revision_intervals")

    val settings: Flow<AppSettings> = context.settingsDataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { p ->
            val defaults = AppSettings()
            AppSettings(
                themeMode = p[themeKey]?.let { s -> ThemeMode.values().firstOrNull { it.name == s } } ?: defaults.themeMode,
                use24Hour = p[use24Key] ?: defaults.use24Hour,
                dailyGoalMinutes = (p[goalKey] ?: defaults.dailyGoalMinutes).coerceIn(1, 1440),
                revisionIntervals = p[intervalsKey]?.let { RevisionScheduler.parseIntervals(it) } ?: defaults.revisionIntervals
            )
        }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.settingsDataStore.edit { it[themeKey] = mode.name }
    }

    suspend fun setUse24Hour(value: Boolean) {
        context.settingsDataStore.edit { it[use24Key] = value }
    }

    suspend fun setDailyGoalMinutes(minutes: Int) {
        context.settingsDataStore.edit { it[goalKey] = minutes.coerceIn(1, 1440) }
    }

    suspend fun setRevisionIntervals(intervals: List<Int>) {
        context.settingsDataStore.edit { it[intervalsKey] = intervals.joinToString(",") }
    }
}
