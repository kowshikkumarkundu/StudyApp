package com.studyflow.app.ui.charts

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.studyflow.app.domain.DayTotals
import com.studyflow.app.util.DurationFormat
import java.time.format.TextStyle
import java.util.Locale

private val BAR_AREA = 110.dp

@Composable
fun StackedDayBars(days: List<DayTotals>, mainColor: Color, revisionColor: Color) {
    val max = (days.maxOfOrNull { it.totalMillis } ?: 0L).coerceAtLeast(1L)
    Row(
        Modifier.fillMaxWidth().height(160.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.Bottom
    ) {
        days.forEach { d ->
            Column(
                Modifier.weight(1f).fillMaxHeight(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Bottom
            ) {
                Text(
                    if (d.totalMillis > 0) DurationFormat.hm(d.totalMillis) else "",
                    style = MaterialTheme.typography.labelSmall
                )
                Box(Modifier.width(18.dp).height(BAR_AREA * (d.revisionMillis.toFloat() / max)).background(revisionColor))
                Box(Modifier.width(18.dp).height(BAR_AREA * (d.mainMillis.toFloat() / max)).background(mainColor))
                Text(
                    d.date.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.getDefault()),
                    style = MaterialTheme.typography.labelSmall
                )
            }
        }
    }
}

@Composable
fun SimpleBars(values: List<Pair<String, Long>>, color: Color) {
    val max = (values.maxOfOrNull { it.second } ?: 0L).coerceAtLeast(1L)
    Row(
        Modifier.fillMaxWidth().height(160.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.Bottom
    ) {
        values.forEach { (label, ms) ->
            Column(
                Modifier.weight(1f).fillMaxHeight(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Bottom
            ) {
                Text(if (ms > 0) DurationFormat.hm(ms) else "", style = MaterialTheme.typography.labelSmall)
                Box(Modifier.width(22.dp).height(BAR_AREA * (ms.toFloat() / max)).background(color))
                Text(label, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
fun HorizontalBars(items: List<Pair<String, Long>>, color: Color) {
    val max = (items.maxOfOrNull { it.second } ?: 0L).coerceAtLeast(1L)
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEach { (label, ms) ->
            Column {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(label, style = MaterialTheme.typography.bodyMedium)
                    Text(DurationFormat.hm(ms), style = MaterialTheme.typography.bodyMedium)
                }
                Box(
                    Modifier
                        .fillMaxWidth((ms.toFloat() / max).coerceIn(0.02f, 1f))
                        .height(10.dp)
                        .background(color, RoundedCornerShape(5.dp))
                )
            }
        }
    }
}

@Composable
fun SplitDonut(mainMillis: Long, revisionMillis: Long, mainColor: Color, revisionColor: Color) {
    val total = (mainMillis + revisionMillis).toFloat()
    val mainSweep = if (total <= 0f) 0f else 360f * mainMillis / total
    val trackColor = MaterialTheme.colorScheme.surfaceVariant
    Canvas(Modifier.size(120.dp)) {
        val stroke = 28f
        val topLeft = Offset(stroke / 2, stroke / 2)
        val arcSize = Size(size.width - stroke, size.height - stroke)
        if (total <= 0f) {
            drawArc(trackColor, 0f, 360f, false, topLeft, arcSize, style = Stroke(stroke))
        } else {
            drawArc(mainColor, -90f, mainSweep, false, topLeft, arcSize, style = Stroke(stroke))
            drawArc(revisionColor, -90f + mainSweep, 360f - mainSweep, false, topLeft, arcSize, style = Stroke(stroke))
        }
    }
}
