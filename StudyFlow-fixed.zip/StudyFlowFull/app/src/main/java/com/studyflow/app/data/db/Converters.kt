package com.studyflow.app.data.db

import androidx.room.TypeConverter

class Converters {
    @TypeConverter fun fromTopicStatus(v: TopicStatus): String = v.name
    @TypeConverter fun toTopicStatus(v: String): TopicStatus = TopicStatus.valueOf(v)

    @TypeConverter fun fromSessionType(v: SessionType): String = v.name
    @TypeConverter fun toSessionType(v: String): SessionType = SessionType.valueOf(v)

    @TypeConverter fun fromRevisionKind(v: RevisionKind): String = v.name
    @TypeConverter fun toRevisionKind(v: String): RevisionKind = RevisionKind.valueOf(v)

    @TypeConverter fun fromRevisionStatus(v: RevisionStatus): String = v.name
    @TypeConverter fun toRevisionStatus(v: String): RevisionStatus = RevisionStatus.valueOf(v)

    @TypeConverter fun fromTimerStatus(v: TimerStatus): String = v.name
    @TypeConverter fun toTimerStatus(v: String): TimerStatus = TimerStatus.valueOf(v)

    @TypeConverter fun fromSessionTypeOrNull(v: SessionType?): String? = v?.name
    @TypeConverter fun toSessionTypeOrNull(v: String?): SessionType? = v?.let { SessionType.valueOf(it) }
}
