package com.studyflow.app.data.repository

import com.studyflow.app.data.db.RevisionEntity
import com.studyflow.app.data.db.StudyFlowDatabase
import com.studyflow.app.data.db.SubjectEntity
import com.studyflow.app.data.db.TopicEntity
import com.studyflow.app.domain.SegmentRecord
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine

data class StatsInput(
    val segments: List<SegmentRecord>,
    val topics: List<TopicEntity>,
    val subjects: List<SubjectEntity>,
    val revisions: List<RevisionEntity>
)

/** Statistics are derived only from saved session segments (never from estimates). */
class StatsRepository(db: StudyFlowDatabase) {
    private val segmentDao = db.segmentDao()
    private val sessionDao = db.studySessionDao()
    private val topicDao = db.topicDao()
    private val subjectDao = db.subjectDao()
    private val revisionDao = db.revisionDao()

    fun observeInput(): Flow<StatsInput> = combine(
        segmentDao.observeAll(),
        sessionDao.observeAll(),
        topicDao.observeAll(),
        subjectDao.observeAll(),
        revisionDao.observeAll()
    ) { segments, sessions, topics, subjects, revisions ->
        val sessionsById = sessions.associateBy { it.id }
        val topicsById = topics.associateBy { it.id }
        val records = segments.mapNotNull { seg ->
            val s = sessionsById[seg.sessionId] ?: return@mapNotNull null
            SegmentRecord(s.type, topicsById[s.topicId]?.subjectId, seg.startWallMillis, seg.endWallMillis, seg.activeMillis)
        }
        StatsInput(records, topics, subjects, revisions)
    }
}
