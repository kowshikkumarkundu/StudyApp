package com.studyflow.app.data.repository

import android.content.Context
import android.net.Uri
import androidx.room.withTransaction
import com.studyflow.app.data.db.RevisionEntity
import com.studyflow.app.data.db.RevisionKind
import com.studyflow.app.data.db.RevisionStatus
import com.studyflow.app.data.db.SessionSegmentEntity
import com.studyflow.app.data.db.SessionType
import com.studyflow.app.data.db.StudyFlowDatabase
import com.studyflow.app.data.db.StudySessionEntity
import com.studyflow.app.data.db.SubjectEntity
import com.studyflow.app.data.db.TopicEntity
import com.studyflow.app.data.db.TopicStatus
import com.studyflow.app.data.settings.AppSettings
import com.studyflow.app.data.settings.SettingsRepository
import com.studyflow.app.data.settings.ThemeMode
import com.studyflow.app.domain.RevisionScheduler
import com.studyflow.app.util.TimeSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/** Local JSON export / import and full data reset. */
class DataRepository(
    private val context: Context,
    private val db: StudyFlowDatabase,
    private val settings: SettingsRepository,
    private val time: TimeSource
) {
    suspend fun exportTo(uri: Uri) = withContext(Dispatchers.IO) {
        val json = buildJson()
        val stream = context.contentResolver.openOutputStream(uri, "wt")
            ?: throw ValidationException("Could not open the file for writing.")
        stream.use { it.write(json.toByteArray(Charsets.UTF_8)) }
    }

    suspend fun importFrom(uri: Uri) = withContext(Dispatchers.IO) {
        val stream = context.contentResolver.openInputStream(uri)
            ?: throw ValidationException("Could not open the file.")
        val bytes = stream.use { it.readBytes() }
        if (bytes.size > MAX_IMPORT_BYTES) throw ValidationException("The file is too large.")
        val backup = parse(String(bytes, Charsets.UTF_8))
        // Single transaction: if anything fails, existing data stays untouched.
        db.withTransaction {
            db.subjectDao().deleteAll()
            db.timerStateDao().clear()
            db.subjectDao().insertAll(backup.subjects)
            db.topicDao().insertAll(backup.topics)
            db.revisionDao().insertAll(backup.revisions)
            db.studySessionDao().insertAll(backup.sessions)
            db.segmentDao().insertAll(backup.segments)
        }
        backup.settings?.let { s ->
            settings.setThemeMode(s.themeMode)
            settings.setUse24Hour(s.use24Hour)
            settings.setDailyGoalMinutes(s.dailyGoalMinutes)
            settings.setRevisionIntervals(s.revisionIntervals)
        }
    }

    /** Deletes all study data (subjects cascade to everything). Settings are kept. */
    suspend fun resetAllData() {
        db.withTransaction {
            db.subjectDao().deleteAll()
            db.timerStateDao().clear()
        }
    }

    private suspend fun buildJson(): String {
        val appSettings = settings.settings.first()
        return db.withTransaction {
            val root = JSONObject()
            root.put("format", FORMAT)
            root.put("version", VERSION)
            root.put("exportedAtMillis", time.wallMillis())
            root.put("settings", JSONObject().apply {
                put("themeMode", appSettings.themeMode.name)
                put("use24Hour", appSettings.use24Hour)
                put("dailyGoalMinutes", appSettings.dailyGoalMinutes)
                put("revisionIntervals", JSONArray(appSettings.revisionIntervals))
            })
            root.put("subjects", JSONArray().also { a ->
                db.subjectDao().getAll().forEach {
                    a.put(JSONObject().put("id", it.id).put("name", it.name).put("createdAtMillis", it.createdAtMillis))
                }
            })
            root.put("topics", JSONArray().also { a ->
                db.topicDao().getAll().forEach {
                    a.put(
                        JSONObject().put("id", it.id).put("subjectId", it.subjectId).put("name", it.name)
                            .put("createdEpochDay", it.createdEpochDay).put("status", it.status.name)
                            .put("autoScheduleGenerated", it.autoScheduleGenerated)
                    )
                }
            })
            root.put("revisions", JSONArray().also { a ->
                db.revisionDao().getAll().forEach {
                    val o = JSONObject().put("id", it.id).put("topicId", it.topicId).put("kind", it.kind.name)
                        .put("scheduledEpochDay", it.scheduledEpochDay).put("status", it.status.name)
                    it.intervalDays?.let { v -> o.put("intervalDays", v) }
                    it.completedAtMillis?.let { v -> o.put("completedAtMillis", v) }
                    a.put(o)
                }
            })
            root.put("sessions", JSONArray().also { a ->
                db.studySessionDao().getAll().forEach {
                    val o = JSONObject().put("id", it.id).put("topicId", it.topicId).put("type", it.type.name)
                        .put("startWallMillis", it.startWallMillis).put("endWallMillis", it.endWallMillis)
                        .put("activeMillis", it.activeMillis)
                    it.revisionId?.let { v -> o.put("revisionId", v) }
                    a.put(o)
                }
            })
            root.put("segments", JSONArray().also { a ->
                db.segmentDao().getAll().forEach {
                    a.put(
                        JSONObject().put("id", it.id).put("sessionId", it.sessionId)
                            .put("startWallMillis", it.startWallMillis).put("endWallMillis", it.endWallMillis)
                            .put("activeMillis", it.activeMillis)
                    )
                }
            })
            root.toString(2)
        }
    }

    private class ParsedBackup(
        val subjects: List<SubjectEntity>,
        val topics: List<TopicEntity>,
        val revisions: List<RevisionEntity>,
        val sessions: List<StudySessionEntity>,
        val segments: List<SessionSegmentEntity>,
        val settings: AppSettings?
    )

    private fun parse(text: String): ParsedBackup {
        try {
            val root = JSONObject(text)
            if (root.optString("format") != FORMAT) throw ValidationException("This is not a StudyFlow backup file.")
            val version = root.optInt("version", -1)
            if (version < 1 || version > VERSION) throw ValidationException("Unsupported backup version: $version.")

            fun JSONObject.longOrNull(key: String): Long? = if (isNull(key)) null else getLong(key)
            fun JSONObject.intOrNull(key: String): Int? = if (isNull(key)) null else getInt(key)
            fun <T> JSONArray?.mapObjects(block: (JSONObject) -> T): List<T> {
                if (this == null) return emptyList()
                return (0 until length()).map { block(getJSONObject(it)) }
            }

            val subjects = root.optJSONArray("subjects").mapObjects {
                SubjectEntity(it.getLong("id"), it.getString("name"), it.getLong("createdAtMillis"))
            }
            val topics = root.optJSONArray("topics").mapObjects {
                TopicEntity(
                    it.getLong("id"), it.getLong("subjectId"), it.getString("name"), it.getLong("createdEpochDay"),
                    TopicStatus.valueOf(it.getString("status")), it.optBoolean("autoScheduleGenerated", false)
                )
            }
            val revisions = root.optJSONArray("revisions").mapObjects {
                RevisionEntity(
                    it.getLong("id"), it.getLong("topicId"), RevisionKind.valueOf(it.getString("kind")),
                    it.intOrNull("intervalDays"), it.getLong("scheduledEpochDay"),
                    RevisionStatus.valueOf(it.getString("status")), it.longOrNull("completedAtMillis")
                )
            }
            val sessions = root.optJSONArray("sessions").mapObjects {
                StudySessionEntity(
                    it.getLong("id"), it.getLong("topicId"), it.longOrNull("revisionId"),
                    SessionType.valueOf(it.getString("type")), it.getLong("startWallMillis"),
                    it.getLong("endWallMillis"), it.getLong("activeMillis")
                )
            }
            val segments = root.optJSONArray("segments").mapObjects {
                SessionSegmentEntity(
                    it.getLong("id"), it.getLong("sessionId"), it.getLong("startWallMillis"),
                    it.getLong("endWallMillis"), it.getLong("activeMillis")
                )
            }
            val s = root.optJSONObject("settings")?.let { o ->
                val defaults = AppSettings()
                val intervals = o.optJSONArray("revisionIntervals")?.let { arr ->
                    RevisionScheduler.parseIntervals((0 until arr.length()).joinToString(",") { arr.getInt(it).toString() })
                } ?: defaults.revisionIntervals
                AppSettings(
                    themeMode = ThemeMode.values().firstOrNull { it.name == o.optString("themeMode") } ?: defaults.themeMode,
                    use24Hour = o.optBoolean("use24Hour", defaults.use24Hour),
                    dailyGoalMinutes = o.optInt("dailyGoalMinutes", defaults.dailyGoalMinutes).coerceIn(1, 1440),
                    revisionIntervals = intervals
                )
            }
            return ParsedBackup(subjects, topics, revisions, sessions, segments, s)
        } catch (e: ValidationException) {
            throw e
        } catch (e: Exception) {
            throw ValidationException("The backup file is damaged or invalid.")
        }
    }

    companion object {
        const val FORMAT = "studyflow-backup"
        const val VERSION = 1
        private const val MAX_IMPORT_BYTES = 50 * 1024 * 1024
    }
}
