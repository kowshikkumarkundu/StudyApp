package com.studyflow.app.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.room.migration.Migration

@Database(
    entities = [
        SubjectEntity::class,
        TopicEntity::class,
        RevisionEntity::class,
        StudySessionEntity::class,
        SessionSegmentEntity::class,
        TimerStateEntity::class
    ],
    version = 1,
    exportSchema = true
)
@TypeConverters(Converters::class)
abstract class StudyFlowDatabase : RoomDatabase() {
    abstract fun subjectDao(): SubjectDao
    abstract fun topicDao(): TopicDao
    abstract fun revisionDao(): RevisionDao
    abstract fun studySessionDao(): StudySessionDao
    abstract fun segmentDao(): SessionSegmentDao
    abstract fun timerStateDao(): TimerStateDao

    companion object {
        @Volatile private var instance: StudyFlowDatabase? = null

        fun getInstance(context: Context): StudyFlowDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    StudyFlowDatabase::class.java,
                    "studyflow.db"
                )
                    .addMigrations(*Migrations.ALL)
                    // No destructive fallback: user data must never be wiped silently.
                    .build()
                    .also { instance = it }
            }
    }
}

/**
 * Every future schema change must bump `version` above and add a Migration here
 * (e.g. MIGRATION_1_2). Exported schemas live in app/schemas/.
 */
object Migrations {
    val ALL: Array<Migration> = emptyArray()
}
