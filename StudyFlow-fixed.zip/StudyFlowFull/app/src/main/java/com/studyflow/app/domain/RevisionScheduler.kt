package com.studyflow.app.domain

import java.time.LocalDate

data class ScheduledRevision(val intervalDays: Int, val date: LocalDate)

object RevisionScheduler {
    val DEFAULT_INTERVALS: List<Int> = listOf(1, 3, 7, 15, 30)
    const val MAX_INTERVAL_DAYS = 365
    const val MAX_INTERVAL_COUNT = 12

    /** Day N means N calendar days after the first study date (day 1 = the next calendar day). */
    fun schedule(firstStudyDate: LocalDate, intervals: List<Int>): List<ScheduledRevision> =
        intervals.filter { it > 0 }.distinct().sorted()
            .map { ScheduledRevision(it, firstStudyDate.plusDays(it.toLong())) }

    /** Parses "1, 3, 7" style input. Returns null when invalid. */
    fun parseIntervals(text: String): List<Int>? {
        val tokens = text.split(',', ';', ' ').map { it.trim() }.filter { it.isNotEmpty() }
        if (tokens.isEmpty() || tokens.size > MAX_INTERVAL_COUNT) return null
        val numbers = tokens.map { it.toIntOrNull() ?: return null }
        if (numbers.any { it !in 1..MAX_INTERVAL_DAYS }) return null
        return numbers.distinct().sorted()
    }
}
