package com.studyflow.app.data.repository

import androidx.room.withTransaction
import com.studyflow.app.data.db.RevisionEntity
import com.studyflow.app.data.db.RevisionKind
import com.studyflow.app.data.db.SessionSegmentEntity
import com.studyflow.app.data.db.SessionType
import com.studyflow.app.data.db.StudyFlowDatabase
import com.studyflow.app.data.db.StudySessionEntity
import com.studyflow.app.data.db.SubjectEntity
import com.studyflow.app.data.db.TimerStatus
import com.studyflow.app.data.db.TopicEntity
import com.studyflow.app.data.db.TopicStatus
import com.studyflow.app.domain.RevisionItem
import com.studyflow.app.domain.RevisionScheduler
import com.studyflow.app.domain.Segment
import com.studyflow.app.domain.TopicItem
import com.studyflow.app.util.TimeSource
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import java.time.Instant

/** Thrown for problems the user can fix (shown as a message, not a crash). */
class ValidationException(message: String) : Exception(message)

class StudyRepository(
    private val db: StudyFlowDatabase,
    private val time: TimeSource
) {
    private val subjectDao = db.subjectDao()
    private val topicDao = db.topicDao()
    private val revisionDao = db.revisionDao()
    private val sessionDao = db.studySessionDao()
    private val segmentDao = db.segmentDao()
    private val timerDao = db.timerStateDao()

    fun observeSubjectNames(): Flow<List<String>> =
        subjectDao.observeAll().map { list -> list.map { it.name } }

    fun observeTopicItems(): Flow<List<TopicItem>> =
        combine(topicDao.observeAll(), subjectDao.observeAll(), sessionDao.observeAll()) { topics, subjects, sessions ->
            val names = subjects.associate { it.id to it.name }
            val byTopic = sessions.filter { it.type == SessionType.MAIN }.groupBy { it.topicId }
            topics.map { t ->
                val s = byTopic[t.id].orEmpty()
                TopicItem(t, names[t.subjectId].orEmpty(), s.size, s.sumOf { it.activeMillis })
            }
        }

    fun observeRevisionItems(): Flow<List<RevisionItem>> =
        combine(revisionDao.observeAll(), topicDao.observeAll(), subjectDao.observeAll()) { revisions, topics, subjects ->
            val subjectNames = subjects.associate { it.id to it.name }
            val topicsById = topics.associateBy { it.id }
            revisions.mapNotNull { r ->
                val t = topicsById[r.topicId] ?: return@mapNotNull null
                RevisionItem(r, t.name, subjectNames[t.subjectId].orEmpty())
            }
        }

    // ---------------- topics ----------------

    suspend fun addTopic(subjectName: String, topicName: String, createdEpochDay: Long): Long =
        db.withTransaction {
            val name = cleanName(topicName, "Topic name")
            val subject = getOrCreateSubject(subjectName)
            topicDao.insert(TopicEntity(subjectId = subject.id, name = name, createdEpochDay = createdEpochDay))
        }

    suspend fun updateTopic(id: Long, subjectName: String, topicName: String) = db.withTransaction {
        val topic = topicDao.getById(id) ?: throw ValidationException("This topic no longer exists.")
        val name = cleanName(topicName, "Topic name")
        val subject = getOrCreateSubject(subjectName)
        topicDao.update(topic.copy(name = name, subjectId = subject.id))
    }

    /** Explicit completion is the only event that creates the automatic revision plan. */
    suspend fun completeTopic(id: Long, intervals: List<Int>) = db.withTransaction {
        val topic = topicDao.getById(id) ?: throw ValidationException("This topic no longer exists.")
        if (topic.autoScheduleGenerated) {
            topicDao.update(topic.copy(status = TopicStatus.COMPLETED))
            return@withTransaction
        }
        val completionDate = java.time.Instant.ofEpochMilli(time.wallMillis())
            .atZone(time.zone()).toLocalDate()
        val revisions = RevisionScheduler.schedule(completionDate, intervals).map {
            RevisionEntity(
                topicId = topic.id,
                kind = RevisionKind.AUTO,
                intervalDays = it.intervalDays,
                scheduledEpochDay = it.date.toEpochDay()
            )
        }
        revisionDao.insertAllIgnoringDuplicates(revisions)
        topicDao.update(topic.copy(status = TopicStatus.COMPLETED, autoScheduleGenerated = true))
    }

    suspend fun deleteTopic(id: Long) = db.withTransaction {
        val timer = timerDao.get()
        if (timer != null && timer.status != TimerStatus.IDLE && timer.topicId == id) {
            throw ValidationException("Stop the active timer before deleting this topic.")
        }
        topicDao.deleteById(id)
    }

    private suspend fun getOrCreateSubject(raw: String): SubjectEntity {
        val name = cleanName(raw, "Subject")
        subjectDao.findByName(name)?.let { return it }
        val id = subjectDao.insert(SubjectEntity(name = name, createdAtMillis = time.wallMillis()))
        return SubjectEntity(id = id, name = name, createdAtMillis = time.wallMillis())
    }

    private fun cleanName(raw: String, label: String): String {
        val value = raw.trim().replace(Regex("\\s+"), " ")
        if (value.isEmpty()) throw ValidationException("$label cannot be empty.")
        if (value.length > MAX_NAME_LENGTH) throw ValidationException("$label is too long (max $MAX_NAME_LENGTH characters).")
        return value
    }

    // ---------------- revisions ----------------

    suspend fun completeRevision(id: Long) {
        revisionDao.markCompleted(id, time.wallMillis())
    }

    /** Manual revisions never touch automatic ones: they are separate rows (kind = MANUAL). */
    suspend fun addManualRevision(topicId: Long, epochDay: Long) = db.withTransaction {
        topicDao.getById(topicId) ?: throw ValidationException("This topic no longer exists.")
        revisionDao.insert(
            RevisionEntity(topicId = topicId, kind = RevisionKind.MANUAL, intervalDays = null, scheduledEpochDay = epochDay)
        )
    }

    suspend fun deleteManualRevision(id: Long) {
        revisionDao.deleteManual(id)
    }

    // ---------------- sessions ----------------

    /** Saves a finished timer session only. Completing a topic is a separate explicit action. */
    suspend fun saveSession(session: StudySessionEntity, segments: List<Segment>): Long =
        db.withTransaction {
            val topic = topicDao.getById(session.topicId)
                ?: throw ValidationException("The topic for this session no longer exists.")
            val revisionId = session.revisionId?.takeIf { revisionDao.getById(it) != null }
            val sessionId = sessionDao.insert(session.copy(id = 0, revisionId = revisionId))
            segmentDao.insertAll(
                segments.map {
                    SessionSegmentEntity(
                        sessionId = sessionId,
                        startWallMillis = it.startMillis,
                        endWallMillis = it.endMillis,
                        activeMillis = it.activeMillis
                    )
                }
            )
            if (session.type == SessionType.MAIN && topic.status == TopicStatus.PLANNED) {
                topicDao.update(topic.copy(status = TopicStatus.IN_PROGRESS))
            }
            sessionId
        }

    companion object {
        const val MAX_NAME_LENGTH = 100
    }
}
