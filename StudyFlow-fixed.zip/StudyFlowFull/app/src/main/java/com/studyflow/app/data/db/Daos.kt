package com.studyflow.app.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface SubjectDao {
    @Insert
    suspend fun insert(subject: SubjectEntity): Long

    @Insert
    suspend fun insertAll(subjects: List<SubjectEntity>)

    @Query("SELECT * FROM subjects WHERE name = :name COLLATE NOCASE LIMIT 1")
    suspend fun findByName(name: String): SubjectEntity?

    @Query("SELECT * FROM subjects ORDER BY name COLLATE NOCASE")
    fun observeAll(): Flow<List<SubjectEntity>>

    @Query("SELECT * FROM subjects")
    suspend fun getAll(): List<SubjectEntity>

    @Query("DELETE FROM subjects")
    suspend fun deleteAll()
}

@Dao
interface TopicDao {
    @Insert
    suspend fun insert(topic: TopicEntity): Long

    @Insert
    suspend fun insertAll(topics: List<TopicEntity>)

    @Update
    suspend fun update(topic: TopicEntity)

    @Query("DELETE FROM topics WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("SELECT * FROM topics WHERE id = :id")
    suspend fun getById(id: Long): TopicEntity?

    @Query("SELECT * FROM topics ORDER BY id")
    fun observeAll(): Flow<List<TopicEntity>>

    @Query("SELECT * FROM topics")
    suspend fun getAll(): List<TopicEntity>
}

@Dao
interface RevisionDao {
    /** IGNORE + the unique index means a second automatic schedule can never be created. */
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAllIgnoringDuplicates(revisions: List<RevisionEntity>): List<Long>

    @Insert
    suspend fun insert(revision: RevisionEntity): Long

    @Insert
    suspend fun insertAll(revisions: List<RevisionEntity>)

    @Query("SELECT * FROM revisions WHERE id = :id")
    suspend fun getById(id: Long): RevisionEntity?

    @Query("SELECT * FROM revisions ORDER BY scheduledEpochDay, id")
    fun observeAll(): Flow<List<RevisionEntity>>

    @Query("SELECT * FROM revisions")
    suspend fun getAll(): List<RevisionEntity>

    /** Only touches status/completedAt of this one row; dates of other revisions never change. */
    @Query("UPDATE revisions SET status = 'COMPLETED', completedAtMillis = :nowMillis WHERE id = :id AND status = 'PENDING'")
    suspend fun markCompleted(id: Long, nowMillis: Long): Int

    @Query("DELETE FROM revisions WHERE id = :id AND kind = 'MANUAL'")
    suspend fun deleteManual(id: Long): Int
}

@Dao
interface StudySessionDao {
    @Insert
    suspend fun insert(session: StudySessionEntity): Long

    @Insert
    suspend fun insertAll(sessions: List<StudySessionEntity>)

    @Query("SELECT * FROM study_sessions ORDER BY startWallMillis DESC")
    fun observeAll(): Flow<List<StudySessionEntity>>

    @Query("SELECT * FROM study_sessions")
    suspend fun getAll(): List<StudySessionEntity>
}

@Dao
interface SessionSegmentDao {
    @Insert
    suspend fun insertAll(segments: List<SessionSegmentEntity>)

    @Query("SELECT * FROM session_segments")
    fun observeAll(): Flow<List<SessionSegmentEntity>>

    @Query("SELECT * FROM session_segments")
    suspend fun getAll(): List<SessionSegmentEntity>
}

@Dao
interface TimerStateDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun save(state: TimerStateEntity)

    @Query("SELECT * FROM timer_state WHERE id = 1")
    suspend fun get(): TimerStateEntity?

    @Query("SELECT * FROM timer_state WHERE id = 1")
    fun observe(): Flow<TimerStateEntity?>

    @Query("DELETE FROM timer_state")
    suspend fun clear()
}
