package com.studyflow.app

import android.content.Context
import com.studyflow.app.data.db.StudyFlowDatabase
import com.studyflow.app.data.repository.DataRepository
import com.studyflow.app.data.repository.StatsRepository
import com.studyflow.app.data.repository.StudyRepository
import com.studyflow.app.data.repository.TimerRepository
import com.studyflow.app.data.settings.SettingsRepository
import com.studyflow.app.util.SystemTimeSource
import com.studyflow.app.util.TimeSource
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/** Simple manual dependency container (no DI framework needed). */
class AppContainer(context: Context) {
    private val appContext = context.applicationContext

    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    val timeSource: TimeSource = SystemTimeSource(appContext)
    val database: StudyFlowDatabase by lazy { StudyFlowDatabase.getInstance(appContext) }
    val settingsRepository: SettingsRepository by lazy { SettingsRepository(appContext) }
    val studyRepository: StudyRepository by lazy { StudyRepository(database, timeSource) }
    val timerRepository: TimerRepository by lazy {
        TimerRepository(database, studyRepository, timeSource)
    }
    val statsRepository: StatsRepository by lazy { StatsRepository(database) }
    val dataRepository: DataRepository by lazy {
        DataRepository(appContext, database, settingsRepository, timeSource)
    }
}
