package com.studyflow.app

import android.app.Application
import kotlinx.coroutines.launch

class StudyFlowApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        // Safely recover a timer that was interrupted by a device restart.
        container.appScope.launch {
            try {
                container.timerRepository.recoverIfNeeded()
            } catch (e: Exception) {
                // Recovery is best-effort; the timer screen handles whatever state remains.
            }
        }
    }
}
