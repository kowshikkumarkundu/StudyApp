package com.studyflow.app.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.studyflow.app.AppContainer
import com.studyflow.app.StudyFlowApp
import com.studyflow.app.data.db.SessionType
import com.studyflow.app.data.repository.StopResult
import com.studyflow.app.data.repository.ValidationException
import com.studyflow.app.data.settings.AppSettings
import com.studyflow.app.data.settings.ThemeMode
import com.studyflow.app.domain.RevisionItem
import com.studyflow.app.domain.RevisionScheduler
import com.studyflow.app.domain.RevisionSections
import com.studyflow.app.domain.Sections
import com.studyflow.app.domain.StatsCalculator
import com.studyflow.app.domain.StatsData
import com.studyflow.app.domain.TimerMath
import com.studyflow.app.domain.TimerUi
import com.studyflow.app.domain.TopicItem
import com.studyflow.app.domain.TopicSections
import com.studyflow.app.data.db.TimerStateEntity
import com.studyflow.app.data.db.TimerStatus
import com.studyflow.app.util.DurationFormat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.ZonedDateTime
import android.net.Uri

class ViewModelFactory(private val container: AppContainer) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = when {
        modelClass.isAssignableFrom(HomeViewModel::class.java) -> HomeViewModel(container)
        modelClass.isAssignableFrom(StatsViewModel::class.java) -> StatsViewModel(container)
        modelClass.isAssignableFrom(SettingsViewModel::class.java) -> SettingsViewModel(container)
        else -> throw IllegalArgumentException("Unknown ViewModel: ${modelClass.name}")
    } as T
}

@Composable
fun appViewModelFactory(): ViewModelProvider.Factory {
    val app = LocalContext.current.applicationContext as StudyFlowApp
    return remember { ViewModelFactory(app.container) }
}

/** Shared helpers: one-second ticker, today's date and one-shot messages. */
abstract class BaseViewModel(protected val container: AppContainer) : ViewModel() {
    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val messages: SharedFlow<String> = _messages

    protected val ticker: Flow<Unit> = flow {
        while (true) {
            emit(Unit)
            delay(1000)
        }
    }

    /** Recomputed every second so it rolls over at midnight and follows timezone changes. */
    val today: StateFlow<LocalDate> = ticker
        .map { LocalDate.now(container.timeSource.zone()) }
        .distinctUntilChanged()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), LocalDate.now(container.timeSource.zone()))

    val settings: StateFlow<AppSettings> = container.settingsRepository.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppSettings())

    fun notify(text: String) {
        _messages.tryEmit(text)
    }

    protected fun launchAction(block: suspend () -> Unit) {
        viewModelScope.launch {
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: ValidationException) {
                notify(e.message ?: "Invalid input.")
            } catch (e: Exception) {
                notify("Something went wrong: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }
}

class HomeViewModel(container: AppContainer) : BaseViewModel(container) {
    private val study = container.studyRepository
    private val timerRepo = container.timerRepository

    val clock: Flow<ZonedDateTime> = flow {
        while (true) {
            emit(ZonedDateTime.now(container.timeSource.zone()))
            delay(1000)
        }
    }

    val allTopics: StateFlow<List<TopicItem>> = study.observeTopicItems()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val subjectNames: StateFlow<List<String>> = study.observeSubjectNames()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val topicSections: StateFlow<TopicSections> = combine(allTopics, today) { topics, d ->
        Sections.topics(topics, d.toEpochDay())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), TopicSections(emptyList(), emptyList()))

    val revisionSections: StateFlow<RevisionSections> =
        combine(study.observeRevisionItems(), today) { items, d -> Sections.revisions(items, d.toEpochDay()) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), RevisionSections(emptyList(), emptyList(), emptyList()))

    val timer: StateFlow<TimerUi> = combine(timerRepo.observe(), ticker, allTopics) { state, _, topics ->
        TimerUi(
            state = state,
            elapsedMillis = TimerMath.activeMillis(
                state.accumulatedActiveMillis,
                state.status == TimerStatus.RUNNING,
                state.lastResumeElapsedRealtime,
                container.timeSource.elapsedRealtime()
            ),
            topicName = topics.firstOrNull { it.topic.id == state.topicId }?.topic?.name
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), TimerUi(TimerStateEntity(), 0L, null))

    init {
        // Periodic checkpoint so an unexpected device restart loses very little time.
        viewModelScope.launch {
            while (true) {
                delay(15_000)
                try {
                    timerRepo.checkpoint()
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    // best effort
                }
            }
        }
    }

    fun addTopic(subject: String, name: String) = launchAction {
        study.addTopic(subject, name, LocalDate.now(container.timeSource.zone()).toEpochDay())
    }

    fun updateTopic(id: Long, subject: String, name: String) = launchAction { study.updateTopic(id, subject, name) }
    fun completeTopic(id: Long) = launchAction {
        val intervals = container.settingsRepository.settings.first().revisionIntervals
        study.completeTopic(id, intervals)
        notify("Topic completed. Revision schedule created.")
    }
    fun deleteTopic(id: Long) = launchAction { study.deleteTopic(id) }

    fun completeRevision(id: Long) = launchAction { study.completeRevision(id) }
    fun addManualRevision(topicId: Long, date: LocalDate) = launchAction { study.addManualRevision(topicId, date.toEpochDay()) }
    fun deleteManualRevision(id: Long) = launchAction { study.deleteManualRevision(id) }

    fun startMain(topicId: Long) = launchAction { timerRepo.start(SessionType.MAIN, topicId) }
    fun startRevision(item: RevisionItem) = launchAction {
        timerRepo.start(SessionType.REVISION, item.revision.topicId, item.revision.id)
    }

    fun pauseTimer() = launchAction { timerRepo.pause() }
    fun resumeTimer() = launchAction { timerRepo.resume() }
    fun stopTimer() = launchAction {
        when (val r = timerRepo.stop()) {
            is StopResult.Saved -> notify("Session saved: ${DurationFormat.hm(r.durationMillis)}")
            StopResult.Discarded -> notify("Session shorter than 1 second was discarded.")
            StopResult.NothingToStop -> Unit
        }
    }
}

class StatsViewModel(container: AppContainer) : BaseViewModel(container) {
    val stats: StateFlow<StatsData?> =
        combine(container.statsRepository.observeInput(), today) { input, d ->
            StatsCalculator.compute(input.segments, input.topics, input.subjects, input.revisions, d, container.timeSource.zone())
        }
            .flowOn(Dispatchers.Default)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)
}

class SettingsViewModel(container: AppContainer) : BaseViewModel(container) {
    private val repo = container.settingsRepository
    private val data = container.dataRepository

    fun setTheme(mode: ThemeMode) = launchAction { repo.setThemeMode(mode) }
    fun setUse24Hour(value: Boolean) = launchAction { repo.setUse24Hour(value) }

    fun saveGoal(text: String) = launchAction {
        val minutes = text.trim().toIntOrNull()
        if (minutes == null || minutes !in 1..1440) throw ValidationException("Enter a goal between 1 and 1440 minutes.")
        repo.setDailyGoalMinutes(minutes)
        notify("Daily goal saved.")
    }

    fun saveIntervals(text: String) = launchAction {
        val parsed = RevisionScheduler.parseIntervals(text)
            ?: throw ValidationException(
                "Use whole days from 1 to ${RevisionScheduler.MAX_INTERVAL_DAYS}, separated by commas (max ${RevisionScheduler.MAX_INTERVAL_COUNT})."
            )
        repo.setRevisionIntervals(parsed)
        notify("Saved. New intervals apply to topics scheduled from now on.")
    }

    fun resetIntervals() = launchAction {
        repo.setRevisionIntervals(RevisionScheduler.DEFAULT_INTERVALS)
        notify("Intervals reset to default.")
    }

    fun exportTo(uri: Uri) = launchAction {
        data.exportTo(uri)
        notify("Backup exported.")
    }

    fun importFrom(uri: Uri) = launchAction {
        data.importFrom(uri)
        notify("Backup imported.")
    }

    fun resetAll() = launchAction {
        data.resetAllData()
        notify("All study data was deleted.")
    }
}
