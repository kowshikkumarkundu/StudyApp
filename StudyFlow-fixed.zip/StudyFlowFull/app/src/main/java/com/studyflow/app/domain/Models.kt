package com.studyflow.app.domain

import com.studyflow.app.data.db.RevisionEntity
import com.studyflow.app.data.db.RevisionStatus
import com.studyflow.app.data.db.SessionType
import com.studyflow.app.data.db.SubjectEntity
import com.studyflow.app.data.db.TimerStateEntity
import com.studyflow.app.data.db.TopicEntity
import com.studyflow.app.data.db.TopicStatus
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId

data class TopicItem(
    val topic: TopicEntity,
    val subjectName: String,
    val mainSessionCount: Int,
    val mainActiveMillis: Long
)

data class RevisionItem(
    val revision: RevisionEntity,
    val topicName: String,
    val subjectName: String
)

data class RevisionSections(
    val today: List<RevisionItem>,
    val upcoming: List<RevisionItem>,
    val missed: List<RevisionItem>
)

data class TopicSections(val today: List<TopicItem>, val earlier: List<TopicItem>)

object Sections {
    /** Today's revisions and missed (overdue) revisions are always separate lists. */
    fun revisions(items: List<RevisionItem>, todayEpochDay: Long): RevisionSections {
        val todayList = items.filter { it.revision.scheduledEpochDay == todayEpochDay }
            .sortedWith(compareBy({ it.revision.status != RevisionStatus.PENDING }, { it.revision.id }))
        val upcoming = items.filter {
            it.revision.status == RevisionStatus.PENDING && it.revision.scheduledEpochDay > todayEpochDay
        }.sortedWith(compareBy({ it.revision.scheduledEpochDay }, { it.revision.id }))
        val missed = items.filter {
            it.revision.status == RevisionStatus.PENDING && it.revision.scheduledEpochDay < todayEpochDay
        }.sortedWith(compareBy({ it.revision.scheduledEpochDay }, { it.revision.id }))
        return RevisionSections(todayList, upcoming, missed)
    }

    fun topics(items: List<TopicItem>, todayEpochDay: Long): TopicSections = TopicSections(
        today = items.filter { it.topic.createdEpochDay == todayEpochDay },
        earlier = items.filter {
            it.topic.createdEpochDay < todayEpochDay && it.topic.status != TopicStatus.COMPLETED
        }
    )
}

data class TimerUi(
    val state: TimerStateEntity,
    val elapsedMillis: Long,
    val topicName: String?
) {
    val isActive: Boolean get() = state.status != com.studyflow.app.data.db.TimerStatus.IDLE
}

// ---------------- statistics ----------------

data class SegmentRecord(
    val type: SessionType,
    val subjectId: Long?,
    val startMillis: Long,
    val endMillis: Long,
    val activeMillis: Long
)

data class DayTotals(val date: LocalDate, val mainMillis: Long, val revisionMillis: Long) {
    val totalMillis: Long get() = mainMillis + revisionMillis
}

data class SubjectTotal(val subjectName: String, val millis: Long)

data class MonthTotal(val month: YearMonth, val millis: Long)

data class StatsData(
    val todayMainMillis: Long,
    val todayRevisionMillis: Long,
    val totalMillis: Long,
    val totalMainMillis: Long,
    val totalRevisionMillis: Long,
    val topicsCompleted: Int,
    val topicsTotal: Int,
    val revisionsCompleted: Int,
    val revisionsTotal: Int,
    val missedRevisions: Int,
    val last7Days: List<DayTotals>,
    val dailyAverageMillis: Long,
    val subjects: List<SubjectTotal>,
    val months: List<MonthTotal>
)

object StatsCalculator {
    fun compute(
        segments: List<SegmentRecord>,
        topics: List<TopicEntity>,
        subjects: List<SubjectEntity>,
        revisions: List<RevisionEntity>,
        today: LocalDate,
        zone: ZoneId
    ): StatsData {
        val perDay = HashMap<Pair<LocalDate, SessionType>, Long>()
        val perSubject = HashMap<Long, Long>()
        var totalMain = 0L
        var totalRevision = 0L

        for (r in segments) {
            val split = SessionSplitter.splitByDate(Segment(r.startMillis, r.endMillis, r.activeMillis), zone)
            for ((date, ms) in split) {
                val key = date to r.type
                perDay[key] = (perDay[key] ?: 0L) + ms
            }
            r.subjectId?.let { perSubject[it] = (perSubject[it] ?: 0L) + r.activeMillis }
            if (r.type == SessionType.MAIN) totalMain += r.activeMillis else totalRevision += r.activeMillis
        }

        fun day(date: LocalDate, type: SessionType): Long = perDay[date to type] ?: 0L

        val last7 = (6 downTo 0).map { back ->
            val d = today.minusDays(back.toLong())
            DayTotals(d, day(d, SessionType.MAIN), day(d, SessionType.REVISION))
        }

        val firstOfMonth = today.withDayOfMonth(1)
        val months = (5 downTo 0).map { back ->
            val ym = YearMonth.from(firstOfMonth.minusMonths(back.toLong()))
            val sum = perDay.entries.filter { YearMonth.from(it.key.first) == ym }.sumOf { it.value }
            MonthTotal(ym, sum)
        }

        val names = subjects.associate { it.id to it.name }
        val subjectTotals = perSubject.entries
            .map { SubjectTotal(names[it.key] ?: "Unknown", it.value) }
            .sortedByDescending { it.millis }

        val todayEpoch = today.toEpochDay()
        return StatsData(
            todayMainMillis = day(today, SessionType.MAIN),
            todayRevisionMillis = day(today, SessionType.REVISION),
            totalMillis = totalMain + totalRevision,
            totalMainMillis = totalMain,
            totalRevisionMillis = totalRevision,
            topicsCompleted = topics.count { it.status == TopicStatus.COMPLETED },
            topicsTotal = topics.size,
            revisionsCompleted = revisions.count { it.status == RevisionStatus.COMPLETED },
            revisionsTotal = revisions.size,
            missedRevisions = revisions.count {
                it.status == RevisionStatus.PENDING && it.scheduledEpochDay < todayEpoch
            },
            last7Days = last7,
            dailyAverageMillis = last7.sumOf { it.totalMillis } / 7,
            subjects = subjectTotals,
            months = months
        )
    }
}
