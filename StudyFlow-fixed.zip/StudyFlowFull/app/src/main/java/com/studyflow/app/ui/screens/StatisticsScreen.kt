package com.studyflow.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.studyflow.app.domain.StatsData
import com.studyflow.app.ui.StatsViewModel
import com.studyflow.app.ui.appViewModelFactory
import com.studyflow.app.ui.charts.HorizontalBars
import com.studyflow.app.ui.charts.SimpleBars
import com.studyflow.app.ui.charts.SplitDonut
import com.studyflow.app.ui.charts.StackedDayBars
import com.studyflow.app.util.DurationFormat
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

@Composable
fun StatisticsScreen(viewModel: StatsViewModel = viewModel(factory = appViewModelFactory())) {
    val stats by viewModel.stats.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val s = stats

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Statistics", style = MaterialTheme.typography.headlineMedium)
        if (s == null) {
            Text("Loading...")
        } else {
            StatsContent(s, settings.dailyGoalMinutes)
        }
    }
}

@Composable
private fun StatsContent(s: StatsData, goalMinutes: Int) {
    val mainColor = MaterialTheme.colorScheme.primary
    val revisionColor = MaterialTheme.colorScheme.tertiary

    StatCard("Today") {
        StatRow("Main study", DurationFormat.hm(s.todayMainMillis))
        StatRow("Revision", DurationFormat.hm(s.todayRevisionMillis))
        val todayTotal = s.todayMainMillis + s.todayRevisionMillis
        val progress = (todayTotal.toFloat() / (goalMinutes * 60_000f)).coerceIn(0f, 1f)
        Text("Daily goal: ${DurationFormat.hm(todayTotal)} of ${DurationFormat.hm(goalMinutes * 60_000L)}")
        LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
    }

    StatCard("Totals") {
        StatRow("Total study duration", DurationFormat.hm(s.totalMillis))
        StatRow("Main topics completed", "${s.topicsCompleted} / ${s.topicsTotal}")
        StatRow("Revisions completed", "${s.revisionsCompleted} / ${s.revisionsTotal}")
    }

    StatCard("Revision status") {
        StatRow("Completed", s.revisionsCompleted.toString())
        StatRow("Missed (overdue)", s.missedRevisions.toString())
    }

    StatCard("Last 7 days") {
        StackedDayBars(s.last7Days, mainColor, revisionColor)
        Legend(mainColor, revisionColor)
        StatRow("Total (7 days)", DurationFormat.hours(s.last7Days.sumOf { it.totalMillis }))
        StatRow("Daily average", DurationFormat.hm(s.dailyAverageMillis))
    }

    StatCard("Main study vs revision") {
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
            SplitDonut(s.totalMainMillis, s.totalRevisionMillis, mainColor, revisionColor)
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Main: ${DurationFormat.hm(s.totalMainMillis)}")
                Text("Revision: ${DurationFormat.hm(s.totalRevisionMillis)}")
            }
        }
    }

    StatCard("Subject-wise study time") {
        if (s.subjects.isEmpty()) Text("No study sessions saved yet.")
        else HorizontalBars(s.subjects.map { it.subjectName to it.millis }, mainColor)
    }

    StatCard("Monthly overview (last 6 months)") {
        SimpleBars(
            s.months.map { it.month.month.getDisplayName(TextStyle.SHORT, Locale.getDefault()) to it.millis },
            mainColor
        )
        val current = s.months.lastOrNull()
        if (current != null) {
            StatRow(current.month.format(DateTimeFormatter.ofPattern("MMMM yyyy")), DurationFormat.hm(current.millis))
        }
    }
}

@Composable
private fun StatCard(title: String, content: @Composable () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            content()
        }
    }
}

@Composable
private fun StatRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label)
        Text(value, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun Legend(mainColor: androidx.compose.ui.graphics.Color, revisionColor: androidx.compose.ui.graphics.Color) {
    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("■ Main study", color = mainColor, style = MaterialTheme.typography.labelMedium)
        Text("■ Revision", color = revisionColor, style = MaterialTheme.typography.labelMedium)
    }
}
