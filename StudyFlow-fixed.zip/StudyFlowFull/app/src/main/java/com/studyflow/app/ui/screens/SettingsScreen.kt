package com.studyflow.app.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.studyflow.app.data.settings.ThemeMode
import com.studyflow.app.ui.SettingsViewModel
import com.studyflow.app.ui.appViewModelFactory
import java.time.LocalDate

@Composable
fun SettingsScreen(viewModel: SettingsViewModel = viewModel(factory = appViewModelFactory())) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(Unit) { viewModel.messages.collect { snackbar.showSnackbar(it) } }

    var goalText by remember(settings.dailyGoalMinutes) { mutableStateOf(settings.dailyGoalMinutes.toString()) }
    var intervalsText by remember(settings.revisionIntervals) { mutableStateOf(settings.revisionIntervals.joinToString(", ")) }
    var pendingImport by remember { mutableStateOf<Uri?>(null) }
    var confirmReset by remember { mutableStateOf(false) }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) viewModel.exportTo(uri)
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) pendingImport = uri
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        contentWindowInsets = WindowInsets(0, 0, 0, 0)
    ) { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Settings", style = MaterialTheme.typography.headlineMedium)

            Heading("Appearance")
            Column(Modifier.selectableGroup()) {
                ThemeMode.values().forEach { mode ->
                    Row(
                        Modifier.fillMaxWidth()
                            .selectable(
                                selected = settings.themeMode == mode,
                                onClick = { viewModel.setTheme(mode) },
                                role = Role.RadioButton
                            )
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = settings.themeMode == mode, onClick = null)
                        Text(
                            mode.name.lowercase().replaceFirstChar { it.uppercase() },
                            modifier = Modifier.padding(start = 12.dp)
                        )
                    }
                }
            }

            HorizontalDivider()
            Heading("Time format")
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Use 24-hour time", Modifier.weight(1f))
                Switch(checked = settings.use24Hour, onCheckedChange = { viewModel.setUse24Hour(it) })
            }

            HorizontalDivider()
            Heading("Daily study goal")
            OutlinedTextField(
                value = goalText,
                onValueChange = { goalText = it.filter { c -> c.isDigit() }.take(4) },
                label = { Text("Minutes per day") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Button(onClick = { viewModel.saveGoal(goalText) }) { Text("Save goal") }

            HorizontalDivider()
            Heading("Revision configuration")
            Text(
                "Days after the first study session, separated by commas. Applies to topics scheduled from now on; existing schedules never change.",
                style = MaterialTheme.typography.bodySmall
            )
            OutlinedTextField(
                value = intervalsText,
                onValueChange = { intervalsText = it.take(60) },
                label = { Text("Revision days") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { viewModel.saveIntervals(intervalsText) }) { Text("Save") }
                OutlinedButton(onClick = { viewModel.resetIntervals() }) { Text("Reset to 1, 3, 7, 15, 30") }
            }

            HorizontalDivider()
            Heading("Data")
            Text("Backups are plain JSON files stored wherever you choose. Nothing leaves your device.", style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { exportLauncher.launch("studyflow-backup-${LocalDate.now()}.json") }) { Text("Export JSON") }
                OutlinedButton(onClick = { importLauncher.launch(arrayOf("*/*")) }) { Text("Import JSON") }
            }
            OutlinedButton(onClick = { confirmReset = true }) {
                Text("Reset all data", color = MaterialTheme.colorScheme.error)
            }
        }
    }

    pendingImport?.let { uri ->
        ConfirmDialog(
            title = "Import backup?",
            message = "This replaces ALL current study data with the contents of the file. This cannot be undone.",
            confirmLabel = "Import",
            onConfirm = { viewModel.importFrom(uri) },
            onDismiss = { pendingImport = null }
        )
    }
    if (confirmReset) {
        ConfirmDialog(
            title = "Reset all data?",
            message = "All subjects, topics, revisions, sessions and the active timer will be permanently deleted. Settings are kept.",
            confirmLabel = "Delete everything",
            onConfirm = { viewModel.resetAll() },
            onDismiss = { confirmReset = false }
        )
    }
}

@Composable
private fun Heading(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
}
