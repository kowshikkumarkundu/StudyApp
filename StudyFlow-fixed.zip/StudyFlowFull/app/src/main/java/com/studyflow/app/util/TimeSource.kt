package com.studyflow.app.util

import android.content.Context
import android.os.SystemClock
import android.provider.Settings
import java.time.ZoneId

/** Abstraction over clocks so timer logic can be tested. */
interface TimeSource {
    /** Wall clock (can be changed by the user / network). Used for timestamps only. */
    fun wallMillis(): Long

    /** Monotonic clock (includes deep sleep, resets on reboot). Used for durations. */
    fun elapsedRealtime(): Long

    /** Number of device boots; changes after a restart. */
    fun bootCount(): Int

    fun zone(): ZoneId
}

class SystemTimeSource(private val context: Context) : TimeSource {
    override fun wallMillis(): Long = System.currentTimeMillis()
    override fun elapsedRealtime(): Long = SystemClock.elapsedRealtime()
    override fun bootCount(): Int = try {
        Settings.Global.getInt(context.contentResolver, Settings.Global.BOOT_COUNT, 0)
    } catch (e: Exception) {
        0
    }
    override fun zone(): ZoneId = ZoneId.systemDefault()
}
