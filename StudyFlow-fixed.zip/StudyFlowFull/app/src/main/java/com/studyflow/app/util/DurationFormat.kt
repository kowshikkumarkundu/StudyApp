package com.studyflow.app.util

import java.util.Locale

object DurationFormat {
    /** 01:05:09 (hours may exceed 24). */
    fun hms(ms: Long): String {
        val total = ms.coerceAtLeast(0L) / 1000
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return String.format(Locale.US, "%02d:%02d:%02d", h, m, s)
    }

    /** "2h 05m", "45m", "<1m" or "0m". */
    fun hm(ms: Long): String {
        val safe = ms.coerceAtLeast(0L)
        val minutes = safe / 60_000
        if (safe > 0 && minutes == 0L) return "<1m"
        val h = minutes / 60
        val m = minutes % 60
        return if (h > 0) "${h}h ${m.toString().padStart(2, '0')}m" else "${m}m"
    }

    fun hours(ms: Long): String = String.format(Locale.US, "%.1f h", ms.coerceAtLeast(0L) / 3_600_000.0)
}
