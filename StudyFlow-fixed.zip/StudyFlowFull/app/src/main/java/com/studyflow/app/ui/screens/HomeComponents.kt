package com.studyflow.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.studyflow.app.data.db.RevisionKind
import com.studyflow.app.data.db.RevisionStatus
import com.studyflow.app.data.db.SessionType
import com.studyflow.app.data.db.TimerStatus
import com.studyflow.app.data.db.TopicStatus
import com.studyflow.app.domain.RevisionItem
import com.studyflow.app.domain.TimerUi
import com.studyflow.app.domain.TopicItem
import com.studyflow.app.util.DurationFormat
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit

@Composable
fun ClockHeader(clock: Flow<ZonedDateTime>, use24Hour: Boolean) {
    val now by clock.collectAsStateWithLifecycle(initialValue = ZonedDateTime.now())
    val timeFormat = remember(use24Hour) {
        DateTimeFormatter.ofPattern(if (use24Hour) "HH:mm:ss" else "hh:mm:ss a")
    }
    val dateFormat = remember { DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy") }
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
        Text(now.format(timeFormat), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(now.format(dateFormat), style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
fun TimerCard(timer: TimerUi, onPause: () -> Unit, onResume: () -> Unit, onStop: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (timer.isActive) MaterialTheme.colorScheme.primaryContainer
            else MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            if (!timer.isActive) {
                Text("No active timer. Tap Start on a topic or a revision.")
            } else {
                val label = if (timer.state.sessionType == SessionType.REVISION) "Revision" else "Main study"
                Text("$label  •  ${timer.topicName ?: "Topic"}", fontWeight = FontWeight.SemiBold)
                Text(DurationFormat.hms(timer.elapsedMillis), style = MaterialTheme.typography.headlineLarge)
                Text(if (timer.state.status == TimerStatus.RUNNING) "Running" else "Paused")
                if (timer.state.wasRecovered) {
                    Text(
                        "Recovered after a restart. Time since the last automatic save was not counted.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (timer.state.status == TimerStatus.RUNNING) {
                        Button(onClick = onPause) { Text("Pause") }
                    } else {
                        Button(onClick = onResume) { Text("Resume") }
                    }
                    OutlinedButton(onClick = onStop) { Text("Stop") }
                }
            }
        }
    }
}

@Composable
fun SectionHeader(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(top = 8.dp)
    )
}

@Composable
fun EmptyHint(text: String) {
    Text(text, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
fun TopicCard(
    item: TopicItem,
    timerActive: Boolean,
    onStart: () -> Unit,
    onComplete: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(item.topic.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Text(item.subjectName, style = MaterialTheme.typography.bodyMedium)
                }
                IconButton(onClick = onEdit) { Icon(Icons.Filled.Edit, contentDescription = "Edit topic") }
                IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, contentDescription = "Delete topic") }
            }
            Text(
                "${item.mainSessionCount} session(s)  •  ${DurationFormat.hm(item.mainActiveMillis)}  •  " +
                    item.topic.status.name.lowercase().replace('_', ' '),
                style = MaterialTheme.typography.bodySmall
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (item.topic.status == TopicStatus.COMPLETED) {
                    Text("Completed", fontWeight = FontWeight.SemiBold)
                } else {
                    OutlinedButton(onClick = onComplete) { Text("Complete") }
                }
                Spacer(Modifier.weight(1f))
                Button(onClick = onStart, enabled = !timerActive && item.topic.status != TopicStatus.COMPLETED) { Text("Start") }
            }
        }
    }
}

@Composable
fun RevisionCard(
    item: RevisionItem,
    today: LocalDate,
    missed: Boolean,
    timerActive: Boolean,
    onStart: () -> Unit,
    onComplete: () -> Unit,
    onDelete: () -> Unit
) {
    val rev = item.revision
    val date = LocalDate.ofEpochDay(rev.scheduledEpochDay)
    val dateText = remember(date) { date.format(DateTimeFormatter.ofPattern("EEE, d MMM yyyy")) }
    val kindText = if (rev.kind == RevisionKind.MANUAL) "Manual" else "Day ${rev.intervalDays}"
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (missed) MaterialTheme.colorScheme.errorContainer
            else MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(item.topicName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Text("${item.subjectName}  •  $kindText", style = MaterialTheme.typography.bodyMedium)
                }
                if (rev.kind == RevisionKind.MANUAL) {
                    IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, contentDescription = "Delete revision") }
                }
            }
            val overdue = if (missed) ChronoUnit.DAYS.between(date, today) else 0L
            Text(
                if (missed) "$dateText  •  overdue by $overdue day(s)" else dateText,
                style = MaterialTheme.typography.bodySmall
            )
            if (rev.status == RevisionStatus.COMPLETED) {
                Text("Completed", fontWeight = FontWeight.SemiBold)
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onStart, enabled = !timerActive) { Text("Start") }
                    OutlinedButton(onClick = onComplete) { Text("Mark done") }
                }
            }
        }
    }
}
