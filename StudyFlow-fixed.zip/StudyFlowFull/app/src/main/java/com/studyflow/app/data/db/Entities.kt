package com.studyflow.app.data.db

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "subjects", indices = [Index(value = ["name"], unique = true)])
data class SubjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val createdAtMillis: Long
)

@Entity(
    tableName = "topics",
    foreignKeys = [ForeignKey(
        entity = SubjectEntity::class,
        parentColumns = ["id"],
        childColumns = ["subjectId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("subjectId")]
)
data class TopicEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subjectId: Long,
    val name: String,
    /** Local calendar date (LocalDate.toEpochDay()). */
    val createdEpochDay: Long,
    val status: TopicStatus = TopicStatus.PLANNED,
    /** Guard: the automatic schedule is generated only once per topic. */
    val autoScheduleGenerated: Boolean = false
)

@Entity(
    tableName = "revisions",
    foreignKeys = [ForeignKey(
        entity = TopicEntity::class,
        parentColumns = ["id"],
        childColumns = ["topicId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [
        Index("topicId"),
        Index("scheduledEpochDay"),
        // Blocks duplicate AUTO revisions (two "day 7" rows for one topic).
        // MANUAL rows have NULL intervalDays, and SQLite treats NULLs as distinct, so they never clash.
        Index(value = ["topicId", "kind", "intervalDays"], unique = true)
    ]
)
data class RevisionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val topicId: Long,
    val kind: RevisionKind,
    val intervalDays: Int? = null,
    val scheduledEpochDay: Long,
    val status: RevisionStatus = RevisionStatus.PENDING,
    val completedAtMillis: Long? = null
)

@Entity(
    tableName = "study_sessions",
    foreignKeys = [
        ForeignKey(
            entity = TopicEntity::class,
            parentColumns = ["id"],
            childColumns = ["topicId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = RevisionEntity::class,
            parentColumns = ["id"],
            childColumns = ["revisionId"],
            onDelete = ForeignKey.SET_NULL
        )
    ],
    indices = [Index("topicId"), Index("revisionId"), Index("startWallMillis")]
)
data class StudySessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val topicId: Long,
    val revisionId: Long? = null,
    val type: SessionType,
    val startWallMillis: Long,
    val endWallMillis: Long,
    /** Active time only (pauses excluded). */
    val activeMillis: Long
)

/** One continuous running interval of a session (resume -> pause/stop). Statistics are built from these. */
@Entity(
    tableName = "session_segments",
    foreignKeys = [ForeignKey(
        entity = StudySessionEntity::class,
        parentColumns = ["id"],
        childColumns = ["sessionId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("sessionId")]
)
data class SessionSegmentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionId: Long,
    val startWallMillis: Long,
    val endWallMillis: Long,
    val activeMillis: Long
)

/** Single-row table (id always 1) holding the live timer so it survives app/device restarts. */
@Entity(tableName = "timer_state")
data class TimerStateEntity(
    @PrimaryKey val id: Int = 1,
    val status: TimerStatus = TimerStatus.IDLE,
    val sessionType: SessionType? = null,
    val topicId: Long? = null,
    val revisionId: Long? = null,
    val startWallMillis: Long? = null,
    /** Active time of all closed segments. */
    val accumulatedActiveMillis: Long = 0,
    /** Monotonic timestamp of the current resume (null unless RUNNING). */
    val lastResumeElapsedRealtime: Long? = null,
    val lastResumeWallMillis: Long? = null,
    val bootCount: Int = 0,
    /** Last periodic save, used to recover safely after a device restart. */
    val checkpointWallMillis: Long? = null,
    val checkpointActiveMillis: Long = 0,
    /** Closed segments encoded as "start,end,active;start,end,active". */
    val closedSegments: String = "",
    val wasRecovered: Boolean = false
)
