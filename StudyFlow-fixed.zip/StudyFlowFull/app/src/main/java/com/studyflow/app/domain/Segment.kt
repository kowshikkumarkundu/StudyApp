package com.studyflow.app.domain

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

/** One continuous running interval. [activeMillis] is measured with the monotonic clock. */
data class Segment(val startMillis: Long, val endMillis: Long, val activeMillis: Long)

object SegmentCodec {
    fun encode(list: List<Segment>): String =
        list.joinToString(";") { "${it.startMillis},${it.endMillis},${it.activeMillis}" }

    fun decode(text: String): List<Segment> {
        if (text.isBlank()) return emptyList()
        return text.split(";").mapNotNull { part ->
            val p = part.split(",")
            if (p.size != 3) return@mapNotNull null
            val s = p[0].toLongOrNull()
            val e = p[1].toLongOrNull()
            val a = p[2].toLongOrNull()
            if (s == null || e == null || a == null) null else Segment(s, e, a)
        }
    }
}

object SessionSplitter {
    /**
     * Splits the active time of a segment across local calendar dates (midnight boundaries in [zone]).
     * The shares always sum to exactly segment.activeMillis.
     */
    fun splitByDate(segment: Segment, zone: ZoneId): Map<LocalDate, Long> {
        val active = segment.activeMillis
        if (active <= 0L) return emptyMap()
        val start = segment.startMillis
        val end = segment.endMillis
        if (end <= start) return mapOf(dateOf(start, zone) to active)

        val totalWall = end - start
        val result = LinkedHashMap<LocalDate, Long>()
        var cursor = start
        var allocated = 0L
        while (cursor < end) {
            val date = dateOf(cursor, zone)
            val nextMidnight = date.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli()
            val chunkEnd = minOf(nextMidnight, end)
            val share = if (chunkEnd >= end) active - allocated else active * (chunkEnd - cursor) / totalWall
            result[date] = (result[date] ?: 0L) + share
            allocated += share
            cursor = chunkEnd
        }
        return result
    }

    private fun dateOf(millis: Long, zone: ZoneId): LocalDate =
        Instant.ofEpochMilli(millis).atZone(zone).toLocalDate()
}

object TimerMath {
    /** Active duration = closed time + (monotonic now - monotonic resume) while running. */
    fun activeMillis(accumulated: Long, running: Boolean, lastResumeElapsed: Long?, nowElapsed: Long): Long {
        val extra = if (running && lastResumeElapsed != null) (nowElapsed - lastResumeElapsed).coerceAtLeast(0L) else 0L
        return accumulated + extra
    }
}
