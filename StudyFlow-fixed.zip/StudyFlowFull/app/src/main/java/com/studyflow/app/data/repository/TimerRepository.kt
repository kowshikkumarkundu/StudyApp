package com.studyflow.app.data.repository

import androidx.room.withTransaction
import com.studyflow.app.data.db.SessionType
import com.studyflow.app.data.db.StudyFlowDatabase
import com.studyflow.app.data.db.StudySessionEntity
import com.studyflow.app.data.db.TimerStateEntity
import com.studyflow.app.data.db.TimerStatus
import com.studyflow.app.domain.Segment
import com.studyflow.app.domain.SegmentCodec
import com.studyflow.app.domain.TimerMath
import com.studyflow.app.util.TimeSource
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

sealed class StopResult {
    object NothingToStop : StopResult()
    object Discarded : StopResult()
    data class Saved(val durationMillis: Long) : StopResult()
}

/**
 * Persistent study timer.
 *  - Durations use the monotonic clock (elapsedRealtime), never the wall clock.
 *  - Wall-clock timestamps are only stored for start/end and day attribution.
 *  - Only one timer can exist (single row in timer_state, guarded by a mutex + transaction).
 *  - State lives in Room, so it survives app kill. After a device restart the monotonic clock
 *    resets, so the session is recovered from the last checkpoint and left PAUSED.
 */
class TimerRepository(
    private val db: StudyFlowDatabase,
    private val studyRepository: StudyRepository,
    private val time: TimeSource
) {
    private val dao = db.timerStateDao()
    private val topicDao = db.topicDao()
    private val revisionDao = db.revisionDao()
    private val mutex = Mutex()

    fun observe(): Flow<TimerStateEntity> = dao.observe().map { it ?: TimerStateEntity() }

    suspend fun start(type: SessionType, topicId: Long, revisionId: Long? = null) = mutex.withLock {
        db.withTransaction {
            val current = dao.get()
            if (current != null && current.status != TimerStatus.IDLE) {
                throw ValidationException("A timer is already active. Stop it first.")
            }
            topicDao.getById(topicId) ?: throw ValidationException("This topic no longer exists.")
            if (revisionId != null && revisionDao.getById(revisionId) == null) {
                throw ValidationException("This revision no longer exists.")
            }
            val wall = time.wallMillis()
            val elapsed = time.elapsedRealtime()
            dao.save(
                TimerStateEntity(
                    status = TimerStatus.RUNNING,
                    sessionType = type,
                    topicId = topicId,
                    revisionId = revisionId,
                    startWallMillis = wall,
                    accumulatedActiveMillis = 0,
                    lastResumeElapsedRealtime = elapsed,
                    lastResumeWallMillis = wall,
                    bootCount = time.bootCount(),
                    checkpointWallMillis = wall,
                    checkpointActiveMillis = 0,
                    closedSegments = "",
                    wasRecovered = false
                )
            )
        }
    }

    suspend fun pause() = mutex.withLock {
        db.withTransaction {
            val s = dao.get()?.let { normalize(it) } ?: return@withTransaction
            if (s.status == TimerStatus.RUNNING) dao.save(closeRunningSegment(s, TimerStatus.PAUSED))
            else dao.save(s)
        }
    }

    suspend fun resume() = mutex.withLock {
        db.withTransaction {
            val s = dao.get()?.let { normalize(it) } ?: return@withTransaction
            if (s.status != TimerStatus.PAUSED) return@withTransaction
            val wall = time.wallMillis()
            dao.save(
                s.copy(
                    status = TimerStatus.RUNNING,
                    lastResumeElapsedRealtime = time.elapsedRealtime(),
                    lastResumeWallMillis = wall,
                    bootCount = time.bootCount(),
                    checkpointWallMillis = wall,
                    checkpointActiveMillis = s.accumulatedActiveMillis,
                    wasRecovered = false
                )
            )
        }
    }

    suspend fun stop(): StopResult {
        val intervals = settings.settings.first().revisionIntervals
        return mutex.withLock {
            db.withTransaction {
                var s = dao.get() ?: return@withTransaction StopResult.NothingToStop
                if (s.status == TimerStatus.IDLE) return@withTransaction StopResult.NothingToStop
                s = normalize(s)
                if (s.status == TimerStatus.RUNNING) s = closeRunningSegment(s, TimerStatus.PAUSED)

                val segments = SegmentCodec.decode(s.closedSegments).filter { it.activeMillis > 0 }
                val total = segments.sumOf { it.activeMillis }
                val type = s.sessionType
                val topicId = s.topicId
                val start = s.startWallMillis
                dao.clear()
                if (type == null || topicId == null || start == null || total < MIN_SESSION_MILLIS) {
                    StopResult.Discarded
                } else {
                    studyRepository.saveSession(
                        StudySessionEntity(
                            topicId = topicId,
                            revisionId = s.revisionId,
                            type = type,
                            startWallMillis = start,
                            endWallMillis = maxOf(time.wallMillis(), start),
                            activeMillis = total
                        ),
                        segments
                    )
                    StopResult.Saved(total)
                }
            }
        }
    }

    /** Called periodically while the app is open so a device restart loses at most a few seconds. */
    suspend fun checkpoint() = mutex.withLock {
        db.withTransaction {
            val s = dao.get() ?: return@withTransaction
            if (s.status != TimerStatus.RUNNING) return@withTransaction
            if (isRebooted(s)) {
                dao.save(recoverFromReboot(s))
            } else {
                val active = TimerMath.activeMillis(s.accumulatedActiveMillis, true, s.lastResumeElapsedRealtime, time.elapsedRealtime())
                dao.save(s.copy(checkpointWallMillis = time.wallMillis(), checkpointActiveMillis = active))
            }
        }
    }

    /** Called at app start: a RUNNING timer after a restart becomes a safe PAUSED one. */
    suspend fun recoverIfNeeded() = mutex.withLock {
        db.withTransaction {
            val s = dao.get() ?: return@withTransaction
            if (s.status == TimerStatus.RUNNING && isRebooted(s)) dao.save(recoverFromReboot(s))
        }
    }

    // ---------------- internals ----------------

    private fun isRebooted(s: TimerStateEntity): Boolean {
        val lastResume = s.lastResumeElapsedRealtime ?: return true
        return s.bootCount != time.bootCount() || time.elapsedRealtime() < lastResume
    }

    private fun normalize(s: TimerStateEntity): TimerStateEntity =
        if (s.status == TimerStatus.RUNNING && isRebooted(s)) recoverFromReboot(s) else s

    private fun closeRunningSegment(s: TimerStateEntity, next: TimerStatus): TimerStateEntity {
        val nowElapsed = time.elapsedRealtime()
        val nowWall = time.wallMillis()
        val active = (nowElapsed - (s.lastResumeElapsedRealtime ?: nowElapsed)).coerceAtLeast(0L)
        val startWall = s.lastResumeWallMillis ?: nowWall
        val segments = SegmentCodec.decode(s.closedSegments) + Segment(startWall, maxOf(nowWall, startWall), active)
        val total = s.accumulatedActiveMillis + active
        return s.copy(
            status = next,
            accumulatedActiveMillis = total,
            closedSegments = SegmentCodec.encode(segments),
            lastResumeElapsedRealtime = null,
            lastResumeWallMillis = null,
            checkpointWallMillis = nowWall,
            checkpointActiveMillis = total
        )
    }

    private fun recoverFromReboot(s: TimerStateEntity): TimerStateEntity {
        val sinceResume = (s.checkpointActiveMillis - s.accumulatedActiveMillis).coerceAtLeast(0L)
        val startWall = s.lastResumeWallMillis ?: s.startWallMillis ?: 0L
        val endWall = maxOf(s.checkpointWallMillis ?: startWall, startWall)
        val existing = SegmentCodec.decode(s.closedSegments)
        val segments = if (sinceResume > 0) existing + Segment(startWall, endWall, sinceResume) else existing
        return s.copy(
            status = TimerStatus.PAUSED,
            accumulatedActiveMillis = s.accumulatedActiveMillis + sinceResume,
            closedSegments = SegmentCodec.encode(segments),
            lastResumeElapsedRealtime = null,
            lastResumeWallMillis = null,
            wasRecovered = true
        )
    }

    companion object {
        const val MIN_SESSION_MILLIS = 1_000L
    }
}
