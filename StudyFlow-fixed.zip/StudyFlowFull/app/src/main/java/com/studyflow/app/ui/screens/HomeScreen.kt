package com.studyflow.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.studyflow.app.domain.RevisionItem
import com.studyflow.app.domain.TopicItem
import com.studyflow.app.ui.HomeViewModel
import com.studyflow.app.ui.appViewModelFactory

@Composable
fun HomeScreen(viewModel: HomeViewModel = viewModel(factory = appViewModelFactory())) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val topicSections by viewModel.topicSections.collectAsStateWithLifecycle()
    val revisions by viewModel.revisionSections.collectAsStateWithLifecycle()
    val timer by viewModel.timer.collectAsStateWithLifecycle()
    val subjects by viewModel.subjectNames.collectAsStateWithLifecycle()
    val allTopics by viewModel.allTopics.collectAsStateWithLifecycle()
    val today by viewModel.today.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(Unit) { viewModel.messages.collect { snackbar.showSnackbar(it) } }

    var tab by rememberSaveable { mutableIntStateOf(0) }
    var showAddTopic by remember { mutableStateOf(false) }
    var editTopic by remember { mutableStateOf<TopicItem?>(null) }
    var deleteTopic by remember { mutableStateOf<TopicItem?>(null) }
    var showManualRevision by remember { mutableStateOf(false) }
    var deleteRevision by remember { mutableStateOf<RevisionItem?>(null) }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        floatingActionButton = {
            if (tab == 0) {
                ExtendedFloatingActionButton(
                    onClick = { showAddTopic = true },
                    icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                    text = { Text("Add topic") }
                )
            } else if (tab == 1) {
                ExtendedFloatingActionButton(
                    onClick = {
                        if (allTopics.isEmpty()) viewModel.notify("Add a topic first.") else showManualRevision = true
                    },
                    icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                    text = { Text("Manual revision") }
                )
            }
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            ClockHeader(viewModel.clock, settings.use24Hour)
            TimerCard(timer, viewModel::pauseTimer, viewModel::resumeTimer, viewModel::stopTimer)
            TabRow(selectedTabIndex = tab) {
                listOf("Study", "Revision", "Missed (${revisions.missed.size})").forEachIndexed { index, title ->
                    Tab(selected = tab == index, onClick = { tab = index }, text = { Text(title) })
                }
            }
            val contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp)
            when (tab) {
                0 -> LazyColumn(
                    contentPadding = contentPadding,
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    item { SectionHeader("Today's topics") }
                    if (topicSections.today.isEmpty()) item { EmptyHint("No topics yet today. Tap \"Add topic\".") }
                    items(topicSections.today, key = { "t${it.topic.id}" }) { item ->
                        TopicCard(
                            item = item,
                            timerActive = timer.isActive,
                            onStart = { viewModel.startMain(item.topic.id) },
                            onComplete = { viewModel.completeTopic(item.topic.id) },
                            onEdit = { editTopic = item },
                            onDelete = { deleteTopic = item }
                        )
                    }
                    if (topicSections.earlier.isNotEmpty()) {
                        item { SectionHeader("Earlier topics (not completed)") }
                        items(topicSections.earlier, key = { "e${it.topic.id}" }) { item ->
                            TopicCard(
                                item = item,
                                timerActive = timer.isActive,
                                onStart = { viewModel.startMain(item.topic.id) },
                                onComplete = { viewModel.completeTopic(item.topic.id) },
                                onEdit = { editTopic = item },
                                onDelete = { deleteTopic = item }
                            )
                        }
                    }
                }

                1 -> LazyColumn(
                    contentPadding = contentPadding,
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    item { SectionHeader("Due today") }
                    if (revisions.today.isEmpty()) item { EmptyHint("No revisions scheduled for today.") }
                    items(revisions.today, key = { "r${it.revision.id}" }) { item ->
                        RevisionCard(
                            item, today, missed = false, timerActive = timer.isActive,
                            onStart = { viewModel.startRevision(item) },
                            onComplete = { viewModel.completeRevision(item.revision.id) },
                            onDelete = { deleteRevision = item }
                        )
                    }
                    item { SectionHeader("Upcoming") }
                    if (revisions.upcoming.isEmpty()) item { EmptyHint("Nothing upcoming.") }
                    items(revisions.upcoming, key = { "u${it.revision.id}" }) { item ->
                        RevisionCard(
                            item, today, missed = false, timerActive = timer.isActive,
                            onStart = { viewModel.startRevision(item) },
                            onComplete = { viewModel.completeRevision(item.revision.id) },
                            onDelete = { deleteRevision = item }
                        )
                    }
                }

                else -> LazyColumn(
                    contentPadding = contentPadding,
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    item { SectionHeader("Missed revisions") }
                    item { EmptyHint("Overdue revisions stay here until you complete them. They never change future dates.") }
                    if (revisions.missed.isEmpty()) item { Text("Nothing missed. Great job!") }
                    items(revisions.missed, key = { "m${it.revision.id}" }) { item ->
                        RevisionCard(
                            item, today, missed = true, timerActive = timer.isActive,
                            onStart = { viewModel.startRevision(item) },
                            onComplete = { viewModel.completeRevision(item.revision.id) },
                            onDelete = { deleteRevision = item }
                        )
                    }
                }
            }
        }
    }

    if (showAddTopic) {
        TopicDialog(
            title = "Add topic",
            initialSubject = "",
            initialName = "",
            subjects = subjects,
            onSave = { s, n -> viewModel.addTopic(s, n) },
            onDismiss = { showAddTopic = false }
        )
    }
    editTopic?.let { item ->
        TopicDialog(
            title = "Edit topic",
            initialSubject = item.subjectName,
            initialName = item.topic.name,
            subjects = subjects,
            onSave = { s, n -> viewModel.updateTopic(item.topic.id, s, n) },
            onDismiss = { editTopic = null }
        )
    }
    deleteTopic?.let { item ->
        ConfirmDialog(
            title = "Delete topic?",
            message = "\"${item.topic.name}\" will be deleted together with its revisions and study sessions. Statistics will change.",
            confirmLabel = "Delete",
            onConfirm = { viewModel.deleteTopic(item.topic.id) },
            onDismiss = { deleteTopic = null }
        )
    }
    deleteRevision?.let { item ->
        ConfirmDialog(
            title = "Delete manual revision?",
            message = "Remove this manual revision for \"${item.topicName}\"?",
            confirmLabel = "Delete",
            onConfirm = { viewModel.deleteManualRevision(item.revision.id) },
            onDismiss = { deleteRevision = null }
        )
    }
    if (showManualRevision) {
        ManualRevisionDialog(
            topics = allTopics,
            today = today,
            onSave = { id, date -> viewModel.addManualRevision(id, date) },
            onDismiss = { showManualRevision = false }
        )
    }
}
