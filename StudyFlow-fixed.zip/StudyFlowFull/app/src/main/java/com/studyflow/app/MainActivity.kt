package com.studyflow.app

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.studyflow.app.data.settings.AppSettings
import com.studyflow.app.ui.navigation.StudyFlowNavHost
import com.studyflow.app.ui.theme.StudyFlowTheme
import com.studyflow.app.ui.theme.isDarkFor
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val container: AppContainer
        get() = (application as StudyFlowApp).container

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val settings by container.settingsRepository.settings
                .collectAsStateWithLifecycle(initialValue = AppSettings())
            StudyFlowTheme(themeMode = settings.themeMode) {
                val dark = isDarkFor(settings.themeMode)
                DisposableEffect(dark) {
                    enableEdgeToEdge(
                        statusBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT) { dark },
                        navigationBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT) { dark }
                    )
                    onDispose { }
                }
                StudyFlowNavHost()
            }
        }
    }

    override fun onStop() {
        super.onStop()
        // Save the running timer's progress whenever the app leaves the foreground.
        container.appScope.launch {
            try {
                container.timerRepository.checkpoint()
            } catch (e: Exception) {
                // best effort
            }
        }
    }
}
