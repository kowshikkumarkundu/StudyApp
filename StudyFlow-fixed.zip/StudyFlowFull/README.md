# StudyFlow

Offline-first study planner for Android: daily topics, automatic spaced revision (1/3/7/15/30 days),
manual revision, a separate Missed list, persistent Main/Revision timers and statistics from real saved sessions.

Automatic revision dates are created only when the user presses the topic-level **Complete** button. Starting, pausing, or stopping a study timer only records the study session; it never completes the topic or creates its revision plan.

Kotlin · Jetpack Compose · Room · MVVM + Repository · Coroutines/Flow · Navigation Compose · min API 26.
No INTERNET permission, no login, no analytics, Auto Backup disabled.

## Open and run (Android Studio)
1. Install the latest stable **Android Studio** and open this folder (File > Open).
2. Wait for Gradle sync (first time needs internet to download libraries).
3. Pick an emulator or a phone with USB debugging, press **Run**.

## Build the debug APK
- Android Studio: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
  Output: `app/build/outputs/apk/debug/app-debug.apk`
- Command line: `./gradlew assembleDebug` (Windows: `gradlew.bat assembleDebug`)

## Cloud APK build (GitHub Actions)
1. Create a GitHub repository and push this project.
2. Open the **Actions** tab > **Android CI** (runs on every push, or press *Run workflow*).
3. When it finishes, download the artifact **studyflow-debug-apk**. The workflow also runs the unit tests.

## Release APK
1. Create a keystore: `keytool -genkeypair -v -keystore studyflow.jks -keyalg RSA -keysize 2048 -validity 10000 -alias studyflow`
2. Create `keystore.properties` in the project root (it is git-ignored):
   ```
   storeFile=studyflow.jks
   storePassword=YOUR_PASSWORD
   keyAlias=studyflow
   keyPassword=YOUR_PASSWORD
   ```
3. Run `./gradlew assembleRelease` > `app/build/outputs/apk/release/app-release.apk`.
Keep the keystore safe: you need the same one for every future update.

## Tests
- Unit tests (no device): `./gradlew testDebugUnitTest`
  Revision dates, day-boundary splitting, timer math, missed vs today separation, statistics, formatters.
- Instrumented tests (emulator/device): `./gradlew connectedDebugAndroidTest`
  Room revision engine (no duplicate schedules), timer pause/stop/reboot recovery, navigation UI.

## How the key rules are implemented
| Rule | Where |
|---|---|
| One automatic schedule per topic | `TopicEntity.autoScheduleGenerated` + unique index on `(topicId, kind, intervalDays)` + `INSERT IGNORE`; all in one transaction (`StudyRepository.saveSession`) |
| Day 1 = next calendar day | `RevisionScheduler.schedule` |
| Missed is separate | derived (PENDING and date < today) in `Sections.revisions`; shown in its own tab |
| Completing missed/manual never shifts dates | `RevisionDao.markCompleted` updates one row only; manual rows are separate (`kind = MANUAL`) |
| Monotonic duration | `TimerRepository` uses `elapsedRealtime`; wall clock only for timestamps |
| One timer only | single-row `timer_state` + mutex + transaction |
| Survives closure / restart | timer state is stored in Room; after a restart the session is recovered from the last checkpoint and left paused |
| Midnight splitting | session *segments* are saved and split by local date in `SessionSplitter` |
| Timezone / date change | "today" is recomputed every second from the device time zone |

## Known limitations
- After a **device restart** the monotonic clock resets, so time since the last automatic save
  (at most about 15 seconds while the app was open) cannot be counted. The app tells you when this happens.
- Changing a topic's name or subject after the fact changes statistics grouping; deleting a topic deletes its sessions (confirmed in a dialog).
- Database changes in future versions need a Room `Migration` in `Migrations.kt` (schemas are exported to `app/schemas`).

## Project layout
`data/db` entities, DAOs, database · `data/repository` repositories · `data/settings` DataStore settings ·
`domain` pure, tested logic · `ui` screens, charts, ViewModels · `util` time source and formatters.
